﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Class
Version=10.5
@EndOfDesignText@

' Координатор data/policy слоя.
' Держит разбор server data, trusted time и policy-block правила отдельно от UI и audio orchestration.

Sub Class_Globals
	Private mainPage As B4XMainPage
End Sub

Public Sub Initialize(target As B4XMainPage)
	mainPage = target
End Sub

' Проверяет, разрешено ли воспроизведение по текущему data snapshot.
Public Sub IsPlaybackAllowed(data As Map, effectiveNowTicks As Long) As Boolean
	If data.IsInitialized = False Then Return True
	Dim playerData As Map = data.GetDefault("player", CreateInitializedMap)
	If playerData.IsInitialized And playerData.ContainsKey("playback_allowed") Then
		If playerData.GetDefault("playback_allowed", True) <> True Then Return False
	End If
	Dim endTimestamp As Long = ResolvePlaybackEndTimestamp(data)
	If endTimestamp <= 0 Then Return True
	Return effectiveNowTicks < (endTimestamp * 1000)
End Sub

' Возвращает человекочитаемую причину policy block на основе текущего data snapshot.
Public Sub ResolvePlaybackBlockReason(data As Map, effectiveNowTicks As Long) As String
	If data.IsInitialized = False Then Return mainPage.Data_MessageValue("playback_paused")
	Dim playerData As Map = data.GetDefault("player", CreateInitializedMap)
	If playerData.IsInitialized Then
		Dim pauseReason As String = playerData.GetDefault("pause_reason", "")
		If pauseReason <> "" Then Return pauseReason
	End If
	Dim endTimestamp As Long = ResolvePlaybackEndTimestamp(data)
	If endTimestamp > 0 And effectiveNowTicks >= (endTimestamp * 1000) Then Return mainPage.Data_MessageValue("subscription_expired")
	If playerData.IsInitialized And playerData.ContainsKey("playback_allowed") Then
		If playerData.GetDefault("playback_allowed", True) <> True Then Return mainPage.Data_MessageValue("playback_paused")
	End If
	Return mainPage.Data_MessageValue("playback_paused")
End Sub

' Ищет effective playback end сначала в player block, затем в top-level response.
Public Sub ResolvePlaybackEndTimestamp(data As Map) As Long
	If data.IsInitialized = False Then Return 0
	Dim playerData As Map = data.GetDefault("player", CreateInitializedMap)
	If playerData.IsInitialized Then
		Dim playerEnd As Long = ParseEndValueToTimestamp(playerData.Get("end"))
		If playerEnd > 0 Then Return playerEnd
	End If
	Return ParseEndValueToTimestamp(data.Get("end"))
End Sub

' Извлекает trusted online time из server data и пишет только монотонно растущее значение.
Public Sub UpdateTrustedOnlineTimeFromData(data As Map, storage As KeyValueStore, storageKey As String)
	Dim candidateTicks As Long = ParseTrustedOnlineTicks(data)
	If candidateTicks <= 0 Then candidateTicks = DateTime.Now
	UpdateTrustedOnlineTimeTicks(candidateTicks, storage, storageKey)
End Sub

Public Sub UpdateTrustedOnlineTimeTicks(candidateTicks As Long, storage As KeyValueStore, storageKey As String)
	If candidateTicks <= 0 Then Return
	Dim storedTicks As Long = storage.GetDefault(storageKey, 0)
	If candidateTicks <= storedTicks Then Return
	storage.Put(storageKey, candidateTicks)
	mainPage.TraceLog("trusted time update ticks=" & candidateTicks)
End Sub

' Вводит player в temporary state без knowledge о том, кто именно вызвал это состояние.
Public Sub HandleTemporaryState(mode As String, text As String)
	mainPage.Data_TraceLog("состояние temporary mode=" & mode & " text=" & text)
	mainPage.Data_ApplyTemporaryMode(mode)
	mainPage.Data_RefreshConnectionIndicatorState
	mainPage.Data_ClearPlaybackState
	mainPage.Data_HidePin
	If text <> "" Then
		mainPage.Data_ShowMessage(text)
	Else If mode = "offline" Then
		mainPage.Data_ShowMessage(mainPage.Data_MessageValue("offline"))
	Else
		mainPage.Data_ShowMessage(mainPage.Data_MessageValue("server_wait"))
	End If
	mainPage.Data_ScheduleRetry(mode, 0)
End Sub

' Переводит player в blocked state и ставит более редкий retry.
Public Sub HandleBlockedState
	mainPage.Data_TraceLog("состояние blocked")
	mainPage.Data_EnterPolicyPause(mainPage.Data_MessageValue("blocked"), "blocked")
	mainPage.Data_ScheduleRetry("blocked", 0)
End Sub

' Останавливает playback при отсутствии valid data и оставляет player в stopped состоянии.
Public Sub StopForMissingData(text As String)
	mainPage.Data_TraceLog("состояние stop reason=missing_data text=" & text)
	mainPage.Data_SetPlaybackFlowState("idle", "missing_data")
	mainPage.Data_ClearPolicyPauseAndResumeRequest
	mainPage.Data_RefreshConnectionIndicatorState
	mainPage.Data_ClearPlaybackState
	mainPage.Data_HidePin
	mainPage.Data_EnterUserStoppedState
	mainPage.Data_SetPlayIcon
	mainPage.Data_ShowMessage(text)
End Sub

' Активация local fallback path без knowledge о playback queue internals.
Public Sub SwitchToLocalPlayback(markDegraded As Boolean, reason As String)
	mainPage.Data_TraceLog("fallback activate mode=local reason=" & reason & " degraded=" & markDegraded)
	mainPage.Data_SetPlaybackFlowState("idle", "switch_local:" & reason)
	mainPage.Data_EnterLocalPlayback
	mainPage.Data_SetMediaPathDegraded(markDegraded)
	mainPage.Data_RequestSkipQueueSnapshotRestore("switch_local:" & reason)
	mainPage.Data_RefreshConnectionIndicatorState
	mainPage.Data_ClearPlaybackState
	mainPage.Data_HidePin
End Sub

' Offline temporary state: если playable local fallback есть, оставляем локальный режим и показываем понятное сообщение.
Public Sub HandleLocalTemporaryState(text As String)
	Dim fallbackReady As Boolean = mainPage.Data_HasLocalPlaybackFallback
	mainPage.Data_TraceLog("состояние temporary mode=offline playableFallback=" & fallbackReady & " text=" & text)
	If fallbackReady Then mainPage.Data_TraceLog("fallback выбор mode=temporary_local reason=playable_local_fallback")
	mainPage.Data_SetPlaybackFlowState("idle", "temporary_local_state")
	mainPage.Data_SetLocalFallbackReady(fallbackReady)
	mainPage.Data_RefreshConnectionIndicatorState
	mainPage.Data_ClearPlaybackState
	mainPage.Data_HidePin
	If text <> "" Then
		mainPage.Data_ShowMessage(text)
	Else
		mainPage.Data_ShowMessage(mainPage.Data_MessageValue("offline"))
	End If
	mainPage.Data_ScheduleRetry("offline", 0)
End Sub

' Policy shutdown message останавливает background refresh и оставляет player в stopped state.
Public Sub HandleShutdownMessage(text As String)
	Dim safeText As String = text
	If safeText = "" Then safeText = mainPage.Data_MessageValue("server_wait")
	mainPage.Data_TraceLog("message shutdown text=" & safeText)
	mainPage.Data_SetPlaybackFlowState("idle", "shutdown")
	mainPage.Data_ClearPolicyPauseAndResumeRequest
	mainPage.Data_ClearPlaybackState
	mainPage.Data_HidePin
	mainPage.Data_EnterUserStoppedState
	mainPage.Data_SetPlayIcon
	mainPage.Data_ShowMessage(safeText)
	mainPage.Data_DisableBackgroundRefreshTimers
End Sub

' Обрабатывает ошибку data fetch и решает, переходить ли в local/server temporary mode.
Public Sub HandleFetchFailure(result As Map) As ResumableSub
	mainPage.Data_TraceLog("очередь fetch ошибка kind=" & result.GetDefault("Kind", "") & " message=" & result.GetDefault("ErrorMessage", ""))
	If result.GetDefault("Kind", "") = "offline" Then
		HandleLocalTemporaryState("")
		Return True
	End If
	If mainPage.Data_HasLocalPlaybackFallback Then
		mainPage.Data_TraceLog("fallback выбор mode=local reason=data_fetch_error")
		HandleLocalTemporaryState("")
		Return True
	End If
	Wait For (CheckServiceAvailability(2500)) Complete (serviceAvailable As Boolean)
	If serviceAvailable Then
		HandleTemporaryState("server", "")
	Else
		HandleTemporaryState("server", "")
	End If
	Return True
End Sub

' Проверяет минимальную доступность backend перед переводом player в temporary state.
Public Sub ResolveRetryDelay(mode As String, delayMs As Int, localRetryMax As Int, serverRetryMax As Int, blockedRetryDelay As Int) As Int
	Return mainPage.Data_ResolveRetryDelay(mode, delayMs, localRetryMax, serverRetryMax, blockedRetryDelay)
End Sub

' Централизует переход в retry state, чтобы page не решала отдельно logging/backoff/policy checks.
Public Sub ScheduleRetry(mode As String, delayMs As Int, localRetryMax As Int, serverRetryMax As Int, blockedRetryDelay As Int)
	mainPage.Data_ClearRetryTimer
	mainPage.Data_SetLastRetryMode(mode)
	mainPage.Data_SetRetryInterval(ResolveRetryDelay(mode, delayMs, localRetryMax, serverRetryMax, blockedRetryDelay))
	If mainPage.Data_IsPlaybackStarted = False Or mainPage.Data_IsStoppedByUser Then Return
	If mainPage.Data_IsPlaybackPausedByPolicy And mode <> "blocked" And mode <> "audio_device" Then Return
	mainPage.Data_TraceWarn("network", "переход в retry", "mode=" & mode & " delaySec=" & Floor(mainPage.Data_GetRetryInterval / 1000))
	mainPage.Data_WriteHealthSnapshot("retry")
	mainPage.Data_EnableRetryTimer
End Sub

Public Sub ResetRetryDelay(localRetryInitial As Int, serverRetryInitial As Int)
	mainPage.Data_ResetRetryDelayState(localRetryInitial, serverRetryInitial)
End Sub

' Обрабатывает media failure через local fallback или offline temporary state.
Public Sub HandleMediaError As ResumableSub
	mainPage.Data_SetPlaybackFlowState("error", "media_error")
	If mainPage.Data_HasLocalPlaybackFallback Then
		mainPage.Data_TraceLog("fallback выбор mode=local reason=media_error")
		SwitchToLocalPlayback(True, "media_failure")
		Return True
	End If
	HandleLocalTemporaryState("Нужен интернет")
	Return True
End Sub

' Централизованный policy-pause вход для server/offline/blocked режимов.
Public Sub PausePlaybackByPolicy(reason As String, connectionMode As String)
	Dim safeReason As String = reason
	If safeReason = "" Then safeReason = mainPage.Data_MessageValue("playback_paused")
	mainPage.Data_EnterPolicyPause(safeReason, connectionMode)
End Sub

' Классифицирует HTTP failures в offline/server для retry и temporary state.
Public Sub ClassifyHttpFailure(errorMessage As String) As String
	If IsOfflineHttpError(errorMessage) Then Return "offline"
	Return "server"
End Sub

' Минимальный backend health-check для принятия решения о temporary mode.
Public Sub CheckServiceAvailability(timeoutMs As Int) As ResumableSub
	Dim j As HttpJob
	j.Initialize("", mainPage)
	Dim params As Map = mainPage.Data_CreateDataParams
	params.Put("t", DateTime.Now)
	j.Download(mainPage.Data_ServiceCheckUrl & "?" & mainPage.Data_BuildParams(params))
	mainPage.Data_ApplyClientRequestHeaders(j)
	j.GetRequest.Timeout = timeoutMs
	Wait For (j) JobDone(j As HttpJob)
	Dim ok As Boolean = j.Success
	j.Release
	Return ok
End Sub

' Единая реакция на HTTP failure для data/history/next paths.
Public Sub LogHttpFailure(url As String, kind As String)
	mainPage.Data_IncrementNetworkErrorCount
	Dim consecutiveErrors As Int = mainPage.Data_GetConsecutiveNetworkErrors
	If url.Contains("/data") Then
		mainPage.Data_TraceWarn("network", "data timeout", "retry=" & consecutiveErrors & " lastDataOkAgoSec=" & mainPage.Data_SecondsAgoText(mainPage.Data_GetLastDataOkAt))
	Else If url.Contains("/history") Then
		mainPage.Data_TraceWarn("history", "ошибка отправки", "kind=" & kind)
	Else If url.Contains("/next") Then
		mainPage.Data_TraceWarn("network", "ошибка очереди", "kind=" & kind)
	End If
End Sub

' Унифицированный JSON GET path для backend-запросов data/next/claim с общей HTTP classification.
Public Sub FetchJsonWithTimeout(url As String, timeoutMs As Int) As ResumableSub
	Dim result As Map
	result.Initialize
	result.Put("Success", False)
	result.Put("Kind", "server")
	result.Put("Data", Null)
	result.Put("ErrorMessage", "")
	Dim j As HttpJob
	j.Initialize("", mainPage)
	mainPage.Data_TraceLog("http get начало timeoutMs=" & timeoutMs & " url=" & url)
	j.Download(url)
	mainPage.Data_ApplyClientRequestHeaders(j)
	j.GetRequest.Timeout = timeoutMs
	Wait For (j) JobDone(j As HttpJob)
	If j.Success Then
		Try
			Dim responseText As String = j.GetString
			mainPage.Data_SaveServerSnapshot("GET", url, True, responseText, "")
			Dim parser As JSONParser
			parser.Initialize(responseText)
			result.Put("Data", parser.NextObject)
			result.Put("Success", True)
			result.Put("Kind", "")
			mainPage.Data_TraceLog("http get итог success=true url=" & url)
		Catch
			result.Put("Kind", "server")
			result.Put("ErrorMessage", "bad_json")
			mainPage.Data_SaveServerSnapshot("GET", url, False, "", "bad_json")
			mainPage.Data_TraceLog("http get ошибка kind=server url=" & url & " message=bad_json")
		End Try
	Else
		Dim errorMessage As String = j.ErrorMessage
		result.Put("ErrorMessage", errorMessage)
		Dim failureKind As String = ClassifyHttpFailure(errorMessage)
		result.Put("Kind", failureKind)
		mainPage.Data_SaveServerSnapshot("GET", url, False, "", errorMessage)
		LogHttpFailure(url, failureKind)
	End If
	j.Release
	Return result
End Sub

' Собирает query-параметры для /next с учётом режима старта и cursor state.
Public Sub CreateNextParams(playerCode As String, deviceId As String, timezoneOffsetMinutes As Int, appVersion As String, startMode As String, playlistIndex As Int) As Map
	Dim params As Map
	params.Initialize
	params.Put("player", playerCode)
	params.Put("device", deviceId)
	params.Put("tz", timezoneOffsetMinutes)
	params.Put("version", appVersion)
	If startMode = "manual" Or startMode = "auto" Then params.Put("start", startMode)
	If playlistIndex >= 0 Then params.Put("playlist", playlistIndex)
	Return params
End Sub

' Собирает query-параметры для /claim.
Public Sub CreateClaimParams(playerCode As String, deviceId As String, timezoneOffsetMinutes As Int) As Map
	Dim params As Map
	params.Initialize
	params.Put("player", playerCode)
	params.Put("device", deviceId)
	params.Put("tz", timezoneOffsetMinutes)
	Return params
End Sub

' Собирает query-параметры для /data.
Public Sub CreateDataParams(playerCode As String, deviceId As String, timezoneOffsetMinutes As Int, clientOsName As String) As Map
	Dim params As Map
	params.Initialize
	params.Put("player", playerCode)
	params.Put("device", deviceId)
	params.Put("tz", timezoneOffsetMinutes)
	params.Put("os", clientOsName)
	Return params
End Sub

' Унифицирует URL encoding query string для backend-запросов.
Public Sub BuildParams(params As Map) As String
	Dim sb As StringBuilder
	sb.Initialize
	For Each key As String In params.Keys
		If sb.Length > 0 Then sb.Append("&")
		sb.Append(UrlEncode(key)).Append("=").Append(UrlEncode(params.Get(key)))
	Next
	Return sb.ToString
End Sub

' Проверяет, есть ли в текущем data slot локально воспроизводимый track.
Public Sub HasPlayableLocalTrackInCurrentSlot(offlineData As Map, effectiveNowTicks As Long) As Boolean
	Dim currentSlot As Map = mainPage.Data_ResolveDataSlotAtTicks(offlineData, effectiveNowTicks)
	If currentSlot.IsInitialized = False Or currentSlot.Size = 0 Then Return False
	Dim playlists As List = currentSlot.GetDefault("playlists", Null)
	If playlists.IsInitialized = False Or playlists.Size = 0 Then Return False
	For Each playlistObject As Object In playlists
		If playlistObject Is Map Then
			Dim playlistDescriptor As Map = playlistObject
			Dim playlistId As String = playlistDescriptor.GetDefault("id", "")
			If playlistId = "" Then Continue
			Dim playlistData As Map = mainPage.Data_LoadCachedPlaylistMetadata(playlistId)
			If PlaylistHasCachedTrack(playlistData) Then Return True
		End If
	Next
	Return False
End Sub

' Строит idle message на основе current/next data slots.
Public Sub ResolveIdleUntilMessage(offlineData As Map, effectiveNowTicks As Long) As String
	If offlineData.IsInitialized = False Then Return ""
	Dim currentSlot As Map = mainPage.Data_ResolveCurrentDataSlot(offlineData)
	If IsIdleSlot(currentSlot) = False Then Return ""
	Dim nextSlot As Map = mainPage.Data_ResolveNextDataSlotAtTicks(offlineData, effectiveNowTicks)
	Dim nextTime As String = nextSlot.GetDefault("slot_time", "")
	If nextTime = "" Then Return mainPage.Data_MessageValue("idle")
	Return mainPage.Data_MessageValue("idle_until").Replace("{time}", nextTime)
End Sub

' Для ad prescan разрешает regular ads только если target minute попадает в не-idle data slot.
Public Sub AllowRegularAdsAtTargetMinute(offlineData As Map, targetMinuteTimestamp As Long) As Boolean
	If offlineData.IsInitialized = False Then Return False
	Dim targetTicks As Long = targetMinuteTimestamp * 1000
	Dim targetSlot As Map = mainPage.Data_ResolveDataSlotAtTicks(offlineData, targetTicks)
	Return IsIdleSlot(targetSlot) = False
End Sub

Private Sub ParseEndValueToTimestamp(value As Object) As Long
	If value = Null Then Return 0
	Dim textValue As String = ("" & value).Trim
	If textValue = "" Then Return 0
	If Regex.IsMatch("^\d+$", textValue) Then Return Floor(textValue)
	If Regex.IsMatch("^\d{4}-\d{2}-\d{2}$", textValue) Then
		Return ParseDateOnlyEndTimestamp(textValue)
	End If
	Try
		Dim instantClass As JavaObject
		instantClass.InitializeStatic("java.time.Instant")
		Dim instant As JavaObject = instantClass.RunMethod("parse", Array As Object(textValue))
		Return instant.RunMethod("getEpochSecond", Null)
	Catch
		mainPage.Data_ConsumeLastException
	End Try
	Try
		Dim offsetDateTimeClass As JavaObject
		offsetDateTimeClass.InitializeStatic("java.time.OffsetDateTime")
		Dim offsetDateTime As JavaObject = offsetDateTimeClass.RunMethod("parse", Array As Object(textValue))
		Dim instant As JavaObject = offsetDateTime.RunMethod("toInstant", Null)
		Return instant.RunMethod("getEpochSecond", Null)
	Catch
		mainPage.Data_ConsumeLastException
	End Try
	mainPage.TraceLog("player end parse fail value=" & textValue)
	Return 0
End Sub

Private Sub ParseTrustedOnlineTicks(data As Map) As Long
	If data.IsInitialized = False Then Return 0
	Dim updatedText As String = ("" & data.GetDefault("updated", "")).Trim
	If updatedText = "" Then Return 0
	Try
		Dim instantClass As JavaObject
		instantClass.InitializeStatic("java.time.Instant")
		Dim instant As JavaObject = instantClass.RunMethod("parse", Array As Object(updatedText))
		Return instant.RunMethod("toEpochMilli", Null)
	Catch
		Try
			Dim offsetDateTimeClass As JavaObject
			offsetDateTimeClass.InitializeStatic("java.time.OffsetDateTime")
			Dim offsetDateTime As JavaObject = offsetDateTimeClass.RunMethod("parse", Array As Object(updatedText))
			Dim instant As JavaObject = offsetDateTime.RunMethod("toInstant", Null)
			Return instant.RunMethod("toEpochMilli", Null)
		Catch
			mainPage.Data_ConsumeLastException
		End Try
	End Try
	Return 0
End Sub

Private Sub ParseDateOnlyEndTimestamp(textValue As String) As Long
	Dim previousDateFormat As String = DateTime.DateFormat
	Try
		DateTime.DateFormat = "yyyy-MM-dd"
		Dim dayStartTicks As Long = DateTime.DateParse(textValue)
		DateTime.DateFormat = previousDateFormat
		Return Floor((dayStartTicks + DateTime.TicksPerDay) / 1000)
	Catch
		DateTime.DateFormat = previousDateFormat
		mainPage.Data_ConsumeLastException
		Return 0
	End Try
End Sub

Private Sub CreateInitializedMap As Map
	Dim m As Map
	m.Initialize
	Return m
End Sub

Private Sub IsIdleSlot(slotContext As Map) As Boolean
	If slotContext.IsInitialized = False Or slotContext.Size = 0 Then Return False
	Dim playlists As List = slotContext.GetDefault("playlists", Null)
	If playlists.IsInitialized And playlists.Size > 0 Then Return False
	Dim streamId As String = slotContext.GetDefault("stream_id", "")
	Dim streamTitle As String = slotContext.GetDefault("stream_title", "")
	Return streamId = "" And streamTitle = ""
End Sub

Private Sub PlaylistHasCachedTrack(playlistData As Map) As Boolean
	If playlistData.IsInitialized = False Or playlistData.Size = 0 Then Return False
	Dim tracks As List = playlistData.GetDefault("tracks", Null)
	If tracks.IsInitialized = False Or tracks.Size = 0 Then Return False
	For Each trackObject As Object In tracks
		If trackObject Is Map Then
			Dim track As Map = trackObject
			Dim trackId As String = track.GetDefault("id", "")
			If trackId <> "" And mainPage.Data_IsTrackCached(trackId) Then Return True
		End If
	Next
	Return False
End Sub

Private Sub UrlEncode(value As Object) As String
	Dim jo As JavaObject
	jo.InitializeStatic("java.net.URLEncoder")
	Return jo.RunMethod("encode", Array As Object("" & value, "UTF-8"))
End Sub

Private Sub IsOfflineHttpError(errorMessage As String) As Boolean
	Dim text As String = errorMessage.ToLowerCase
	If text.Contains("timed out") Then Return True
	If text.Contains("unknownhost") Then Return True
	If text.Contains("refused") Then Return True
	If text.Contains("sslhandshakeexception") Then Return True
	If text.Contains("pkix path building failed") Then Return True
	If text.Contains("unable to find valid certification path") Then Return True
	If text.Contains("connectexception") Then Return True
	If text.Contains("socketexception") Then Return True
	If text.Contains("sockettimeoutexception") Then Return True
	Return False
End Sub
