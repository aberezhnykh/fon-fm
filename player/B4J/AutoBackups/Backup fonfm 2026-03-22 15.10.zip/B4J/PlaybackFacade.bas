﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Class
Version=10.5
@EndOfDesignText@

Sub Class_Globals
	Private parent As Object
End Sub

Public Sub Initialize(target As Object)
	parent = target
End Sub

Private Sub Trace(message As String)
	If parent = Null Then Return
	CallSub2(parent, "PlaybackFacade_Trace", message)
End Sub

Public Sub StartFirstTrack(mode As String) As ResumableSub
	Trace("PlaybackFacade start requested. mode=" & mode)
	Wait For (CallSub2(parent, "Facade_StartFirstTrackCore", mode)) Complete (started As Boolean)
	Return started
End Sub

Public Sub LoadNextAndPlay As ResumableSub
	Trace("PlaybackFacade advance requested. mode=load_next_and_play")
	Wait For (CallSub(parent, "Facade_LoadNextAndPlayCore")) Complete (advanced As Boolean)
	Return advanced
End Sub

Public Sub DispatchPlaybackAdvance(initiator As String, allowLoad As Boolean) As ResumableSub
	Trace("PlaybackFacade advance requested. initiator=" & initiator & ", allowLoad=" & allowLoad)
	Wait For (CallSub3(parent, "Facade_DispatchPlaybackAdvanceCore", initiator, allowLoad)) Complete (advanced As Boolean)
	Return advanced
End Sub

Public Sub PrepareNextPlayable As ResumableSub
	Wait For (CallSub(parent, "Facade_PrepareNextPlayableCore")) Complete (prepared As Boolean)
	Return prepared
End Sub

Public Sub AdvanceAfterComplete(audioKey As String) As ResumableSub
	Trace("PlaybackFacade advance requested. initiator=audio_complete:" & audioKey)
	Wait For (DispatchPlaybackAdvance("audio_complete:" & audioKey, True)) Complete (advanced As Boolean)
	Return advanced
End Sub

Public Sub AdvanceAfterError(audioKey As String) As ResumableSub
	Trace("PlaybackFacade advance requested. initiator=audio_error_recovery:" & audioKey)
	Wait For (DispatchPlaybackAdvance("audio_error_recovery:" & audioKey, True)) Complete (advanced As Boolean)
	Return advanced
End Sub

Public Sub StopPlayback As ResumableSub
	Trace("PlaybackFacade stop requested.")
	Wait For (CallSub(parent, "Facade_StopPlayerCore")) Complete (stopped As Boolean)
	Return stopped
End Sub

Public Sub PausePlayback(reason As String, connectionMode As String)
	Trace("PlaybackFacade pause requested. mode=" & connectionMode)
	CallSub3(parent, "Facade_PausePlaybackCore", reason, connectionMode)
End Sub

Public Sub ResumePlaybackAfterPolicyPause As ResumableSub
	Trace("PlaybackFacade resume requested. reason=policy_pause")
	Wait For (CallSub(parent, "Facade_ResumePlaybackAfterPolicyPauseCore")) Complete (resumed As Boolean)
	Return resumed
End Sub

Public Sub CompleteStartupSequence
	CallSub(parent, "Facade_CompleteStartupSequenceCore")
End Sub
