﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Class
Version=10.5
@EndOfDesignText@

Sub Class_Globals
	Private targetModule As Object
	Private traceSubName As String
	Private adLabelText As String
	Private lastScanMinuteKey As String = ""
	Private lastInjectedMinuteKey As String = ""
End Sub

Public Sub Initialize(targetModuleValue As Object, traceSubNameValue As String, adLabelTextValue As String)
	targetModule = targetModuleValue
	traceSubName = traceSubNameValue
	adLabelText = adLabelTextValue
End Sub

Public Sub Reset
	lastScanMinuteKey = ""
	lastInjectedMinuteKey = ""
End Sub

Public Sub ScanCurrentMinute(offlineData As Map, playQueue As List, force As Boolean) As Boolean
	If offlineData.IsInitialized = False Then Return False
	If offlineData.GetDefault("ok", False) <> True Then Return False
	If playQueue.IsInitialized = False Then Return False
	Dim minuteKey As String = CurrentLocalMinuteKey
	If force = False And minuteKey = lastScanMinuteKey Then Return False
	lastScanMinuteKey = minuteKey
	Dim breakItem As Map = BuildCurrentMinuteBreak(offlineData)
	If breakItem.IsInitialized = False Or breakItem.Size = 0 Then Return False
	Dim breakAt As Long = ToLongDefault(breakItem.GetDefault("at", -1), -1)
	If breakAt <= 0 Then Return False
	If HasBreakScheduledAt(playQueue, breakAt) Then
		lastInjectedMinuteKey = minuteKey
		Trace("Локальный break уже есть в очереди. at=" & breakAt)
		Return False
	End If
	If lastInjectedMinuteKey = minuteKey Then Return False
	playQueue.InsertAt(0, breakItem)
	lastInjectedMinuteKey = minuteKey
	Trace("Локальный break добавлен в начало очереди. minute=" & minuteKey & ", items=" & breakItem.GetDefault("items_count", 0) & ", queueSize=" & playQueue.Size)
	Return True
End Sub

Private Sub BuildCurrentMinuteBreak(offlineData As Map) As Map
	Dim emptyBreak As Map
	emptyBreak.Initialize
	Dim ads As List = offlineData.GetDefault("ads", Null)
	If ads.IsInitialized = False Or ads.Size = 0 Then Return emptyBreak
	Dim todayKey As String = FormatIsoDate(DateTime.Now)
	Dim todayWeekday As String = CurrentIsoWeekday
	Dim currentMinuteOfDay As Int = CurrentMinutesOfDay
	Dim slotTimestamp As Long = CurrentLocalMinuteTimestamp
	Dim dueItems As List
	dueItems.Initialize
	For Each adObject As Object In ads
		If adObject Is Map Then
			Dim ad As Map = adObject
			If AdMatchesCurrentMinute(ad, todayKey, todayWeekday, currentMinuteOfDay) Then
				dueItems.Add(CreateAdQueueItem(ad))
			End If
		End If
	Next
	If dueItems.Size = 0 Then Return emptyBreak
	Dim breakItem As Map
	breakItem.Initialize
	breakItem.Put("type", "break")
	breakItem.Put("exactly", True)
	breakItem.Put("at", slotTimestamp)
	breakItem.Put("items", dueItems)
	breakItem.Put("items_count", dueItems.Size)
	Return breakItem
End Sub

Private Sub AdMatchesCurrentMinute(ad As Map, todayKey As String, todayWeekday As String, currentMinuteOfDay As Int) As Boolean
	If ad.IsInitialized = False Then Return False
	Dim startDate As String = ad.GetDefault("start", "")
	If startDate <> "" And startDate.CompareTo(todayKey) > 0 Then Return False
	Dim endDate As String = ad.GetDefault("end", "")
	If endDate <> "" And endDate.CompareTo(todayKey) < 0 Then Return False
	Dim weekdays As List = ad.GetDefault("weekdays", Null)
	If weekdays.IsInitialized And weekdays.Size > 0 Then
		Dim weekdayMatched As Boolean = False
		For Each weekdayObject As Object In weekdays
			If ("" & weekdayObject).Trim = todayWeekday Then
				weekdayMatched = True
				Exit
			End If
		Next
		If weekdayMatched = False Then Return False
	End If
	Dim baseMinute As Int = TimeStringToMinutes(ad.GetDefault("time", ""))
	If baseMinute < 0 Then Return False
	If currentMinuteOfDay < baseMinute Then Return False
	Dim intervalMinutes As Int = ToLongDefault(ad.GetDefault("interval", 0), 0)
	If intervalMinutes <= 0 Then Return currentMinuteOfDay = baseMinute
	Return ((currentMinuteOfDay - baseMinute) Mod intervalMinutes) = 0
End Sub

Private Sub CreateAdQueueItem(ad As Map) As Map
	Dim item As Map
	item.Initialize
	item.Put("type", "ad")
	item.Put("id", ad.GetDefault("id", ""))
	item.Put("title", ad.GetDefault("title", adLabelText))
	item.Put("duration", ToLongDefault(ad.GetDefault("duration", 0), 0))
	item.Put("gain", ad.GetDefault("gain", -3))
	Return item
End Sub

Private Sub HasBreakScheduledAt(playQueue As List, breakAt As Long) As Boolean
	If breakAt <= 0 Then Return False
	For Each itemObject As Object In playQueue
		If itemObject Is Map Then
			Dim item As Map = itemObject
			If item.GetDefault("type", "") = "break" And ToLongDefault(item.GetDefault("at", -1), -1) = breakAt Then Return True
		End If
	Next
	Return False
End Sub

Private Sub Trace(message As String)
	If SubExists(targetModule, traceSubName) Then
		CallSub2(targetModule, traceSubName, message)
	End If
End Sub

Private Sub FormatIsoDate(ticks As Long) As String
	Dim previousDateFormat As String = DateTime.DateFormat
	DateTime.DateFormat = "yyyy-MM-dd"
	Dim value As String = DateTime.Date(ticks)
	DateTime.DateFormat = previousDateFormat
	Return value
End Sub

Private Sub CurrentMinutesOfDay As Int
	Dim previousTimeFormat As String = DateTime.TimeFormat
	DateTime.TimeFormat = "HH:mm:ss"
	Dim timeValue As String = DateTime.Time(DateTime.Now)
	DateTime.TimeFormat = previousTimeFormat
	Dim parts() As String = Regex.Split(":", timeValue)
	If parts.Length < 2 Then Return 0
	Return parts(0) * 60 + parts(1)
End Sub

Private Sub CurrentIsoWeekday As String
	Dim jo As JavaObject
	jo.InitializeStatic("java.time.LocalDate")
	Dim today As JavaObject = jo.RunMethod("now", Null)
	Dim dayOfWeek As JavaObject = today.RunMethod("getDayOfWeek", Null)
	Return "" & dayOfWeek.RunMethod("getValue", Null)
End Sub

Private Sub CurrentLocalMinuteTimestamp As Long
	Dim localNow As Long = LocalNowTimestamp
	Return localNow - (localNow Mod 60)
End Sub

Private Sub CurrentLocalMinuteKey As String
	Dim previousDateFormat As String = DateTime.DateFormat
	Dim previousTimeFormat As String = DateTime.TimeFormat
	DateTime.DateFormat = "yyyy-MM-dd"
	DateTime.TimeFormat = "HH:mm"
	Dim value As String = DateTime.Date(DateTime.Now) & " " & DateTime.Time(DateTime.Now)
	DateTime.DateFormat = previousDateFormat
	DateTime.TimeFormat = previousTimeFormat
	Return value
End Sub

Private Sub TimeStringToMinutes(value As String) As Int
	If value = "" Then Return -1
	Dim parts() As String = Regex.Split(":", value)
	If parts.Length < 2 Then Return -1
	Try
		Dim hours As Int = parts(0)
		Dim minutes As Int = parts(1)
		If hours < 0 Or hours > 23 Then Return -1
		If minutes < 0 Or minutes > 59 Then Return -1
		Return hours * 60 + minutes
	Catch
		Return -1
	End Try
End Sub

Private Sub LocalNowTimestamp As Long
	Dim jo As JavaObject
	jo.InitializeStatic("java.time.OffsetDateTime")
	Dim nowOffset As JavaObject = jo.RunMethod("now", Null)
	Dim zoneOffset As JavaObject = nowOffset.RunMethod("getOffset", Null)
	Dim totalSeconds As Int = zoneOffset.RunMethod("getTotalSeconds", Null)
	Dim timezoneOffsetMinutes As Int = -Round(totalSeconds / 60)
	Return Floor(DateTime.Now / 1000) - (timezoneOffsetMinutes * 60)
End Sub

Private Sub ToLongDefault(value As Object, defaultValue As Long) As Long
	Try
		If value = Null Then Return defaultValue
		Return value
	Catch
		Try
			Return Floor(("" & value).Trim)
		Catch
			Return defaultValue
		End Try
	End Try
End Sub
