﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Class
Version=10.5
@EndOfDesignText@

Sub Class_Globals
	Public Slots As List
	Public IsTickInProgress As Boolean
	Public DecisionEpoch As Long
	Public CurrentDecision As String
End Sub

Public Sub Initialize
	Reset
End Sub

Public Sub Reset
	Slots.Initialize
	IsTickInProgress = False
	DecisionEpoch = 0
	CurrentDecision = ""
End Sub

Public Sub ConfigureDefaultSlots
	If Slots.IsInitialized = False Then Slots.Initialize
	If Slots.Size > 0 Then Return
	Slots.Add(CreateSlot("slot_primary", "primary"))
	Slots.Add(CreateSlot("slot_secondary", "secondary"))
	Slots.Add(CreateSlot("slot_interrupt", ""))
End Sub

Public Sub ApplyLegacyRuntime(runtimeState As PlaybackRuntimeState)
	ConfigureDefaultSlots
	For Each slot As PlaybackPlayerSlot In Slots
		slot.Reset
	Next
	If runtimeState.ActiveAudioKey <> "" Then
		Dim activeSlot As PlaybackPlayerSlot = GetSlotByAudioKey(runtimeState.ActiveAudioKey)
		If activeSlot.IsInitialized Then
			activeSlot.SetRoleState("active", "playing")
			activeSlot.SetItem(runtimeState.ActiveItem)
		End If
	End If
	If runtimeState.PendingPlayAudioKey <> "" Then
		Dim pendingPlaySlot As PlaybackPlayerSlot = GetSlotByAudioKey(runtimeState.PendingPlayAudioKey)
		If pendingPlaySlot.IsInitialized Then
			pendingPlaySlot.SetRoleState("pending_play", "loading")
			pendingPlaySlot.SetItem(runtimeState.PendingPlayItem)
		End If
	End If
	If runtimeState.PreparedAudioKey <> "" Then
		Dim preparedSlot As PlaybackPlayerSlot = GetSlotByAudioKey(runtimeState.PreparedAudioKey)
		If preparedSlot.IsInitialized Then
			preparedSlot.SetRoleState(ResolvePreparedRole(runtimeState.PreparedItem), "ready")
			preparedSlot.SetItem(runtimeState.PreparedItem)
		End If
	End If
	If runtimeState.PendingPrepareAudioKey <> "" Then
		Dim pendingPrepareSlot As PlaybackPlayerSlot = GetSlotByAudioKey(runtimeState.PendingPrepareAudioKey)
		If pendingPrepareSlot.IsInitialized Then
			pendingPrepareSlot.SetRoleState(ResolvePendingPrepareRole(runtimeState.PendingPrepareItem), "loading")
			pendingPrepareSlot.SetItem(runtimeState.PendingPrepareItem)
		End If
	End If
End Sub

Public Sub GetSlotByAudioKey(audioKey As String) As PlaybackPlayerSlot
	For Each slot As PlaybackPlayerSlot In Slots
		If slot.AudioKey = audioKey Then Return slot
	Next
	Dim emptySlot As PlaybackPlayerSlot
	Return emptySlot
End Sub

Public Sub GetSlotByRole(roleValue As String) As PlaybackPlayerSlot
	For Each slot As PlaybackPlayerSlot In Slots
		If slot.Role = roleValue Then Return slot
	Next
	Dim emptySlot As PlaybackPlayerSlot
	Return emptySlot
End Sub

Public Sub DescribeSlots As String
	Dim parts As List
	parts.Initialize
	For Each slot As PlaybackPlayerSlot In Slots
		Dim itemId As String = ""
		If slot.HasItem Then itemId = slot.Item.GetDefault("id", "")
		parts.Add(slot.SlotId & ":" & slot.Role & ":" & slot.State & ":" & itemId)
	Next
	Return JoinParts(parts)
End Sub

Public Sub BeginDecision(decisionName As String)
	DecisionEpoch = DecisionEpoch + 1
	CurrentDecision = decisionName
End Sub

Public Sub ClearDecision
	CurrentDecision = ""
End Sub

Private Sub ResolvePreparedRole(item As Map) As String
	If item.IsInitialized = False Then Return "prepared"
	If item.GetDefault("type", "") = "ad" Then Return "prepared_interrupt"
	Return "prepared_music"
End Sub

Private Sub ResolvePendingPrepareRole(item As Map) As String
	If item.IsInitialized = False Then Return "pending_prepare"
	If item.GetDefault("type", "") = "ad" Then Return "pending_interrupt"
	Return "pending_prepare_music"
End Sub

Private Sub CreateSlot(slotIdValue As String, audioKeyValue As String) As PlaybackPlayerSlot
	Dim slot As PlaybackPlayerSlot
	slot.Initialize(slotIdValue, audioKeyValue)
	Return slot
End Sub

Private Sub JoinParts(parts As List) As String
	Dim sb As StringBuilder
	sb.Initialize
	For i = 0 To parts.Size - 1
		If i > 0 Then sb.Append(" | ")
		sb.Append(parts.Get(i))
	Next
	Return sb.ToString
End Sub
