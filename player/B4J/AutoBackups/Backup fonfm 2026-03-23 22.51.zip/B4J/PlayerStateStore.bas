﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Class
Version=10.5
@EndOfDesignText@

' Контракт локального состояния player.
' Coordinator / network worker общаются с приложением через этот store, а не напрямую с page internals.

Sub Class_Globals
	Private owner As B4XMainPage
	Private policyState As PlaybackDataPolicyState
	Private orchestrationStateRef As PlaybackOrchestrationState
	Private retryFallbackStateRef As PlaybackRetryFallbackState
	Private offlineStoreRef As OfflineStore
	Private dataResolverRef As DataPlaybackResolver
	Private mediaCacheRef As MediaCache
	Private storageRef As KeyValueStore
	Private trustedSyncTimeKeyValue As String
	Private retryTimerRef As Timer
	Private offlineDataRef As Map
	Private consecutiveNetworkErrors As Int
	Private lastRetryMode As String
	Private dataSuccessAtTicks As Long
	Private historySuccessAtTicks As Long
	Private startupSequenceInProgress As Boolean
	Private adWarmupDeferredAfterStartup As Boolean
End Sub

Public Sub Initialize(target As B4XMainPage, retryTimer As Timer, dataPolicy As PlaybackDataPolicyState, orchestrationState As PlaybackOrchestrationState, retryFallbackState As PlaybackRetryFallbackState, storageValue As KeyValueStore, trustedSyncKey As String, offlineStore As OfflineStore, dataResolver As DataPlaybackResolver, mediaCache As MediaCache)
	owner = target
	policyState = dataPolicy
	orchestrationStateRef = orchestrationState
	retryFallbackStateRef = retryFallbackState
	offlineStoreRef = offlineStore
	dataResolverRef = dataResolver
	mediaCacheRef = mediaCache
	storageRef = storageValue
	trustedSyncTimeKeyValue = trustedSyncKey
	retryTimerRef = retryTimer
	offlineDataRef.Initialize
End Sub

Public Sub IncrementNetworkErrorCount
	consecutiveNetworkErrors = consecutiveNetworkErrors + 1
End Sub

Public Sub ResetConsecutiveNetworkErrors
	consecutiveNetworkErrors = 0
End Sub

Public Sub GetConsecutiveNetworkErrors As Int
	Return consecutiveNetworkErrors
End Sub

Public Sub SetLastRetryMode(mode As String)
	lastRetryMode = mode
End Sub

Public Sub GetLastRetryMode As String
	Return lastRetryMode
End Sub

Public Sub ClearLastRetryMode
	lastRetryMode = ""
End Sub

Public Sub SetLastDataOkNow
	dataSuccessAtTicks = DateTime.Now
End Sub

Public Sub GetLastDataOkAt As Long
	Return dataSuccessAtTicks
End Sub

Public Sub SetLastHistoryOkNow
	historySuccessAtTicks = DateTime.Now
End Sub

Public Sub GetLastHistoryOkAt As Long
	Return historySuccessAtTicks
End Sub

Public Sub PlayerCodeValue As String
	Return owner.PlayerCodeValue
End Sub

Public Sub DeviceIdValue As String
	Return owner.DeviceIdValue
End Sub

Public Sub TimezoneOffsetMinutesValue As Int
	Return owner.TimezoneOffsetMinutesValue
End Sub

Public Sub ClientOsNameValue As String
	Return owner.ClientOsNameValue
End Sub

Public Sub ServiceCheckUrlValue As String
	Return owner.ServiceCheckUrlValue
End Sub

Public Sub DataUrlValue As String
	Return owner.DataUrlValue
End Sub

Public Sub NextUrlValue As String
	Return owner.NextUrlValue
End Sub

Public Sub ClaimUrlValue As String
	Return owner.ClaimUrlValue
End Sub

Public Sub MessageValue(key As String) As String
	Return owner.Data_MessageValue(key)
End Sub

Public Sub TraceLog(message As String)
	owner.Data_TraceLog(message)
End Sub

Public Sub TraceInfo(category As String, message As String, details As String)
	owner.Data_TraceInfo(category, message, details)
End Sub

Public Sub TraceWarn(category As String, message As String, details As String)
	owner.Data_TraceWarn(category, message, details)
End Sub

Public Sub ConsumeLastException
	owner.Data_ConsumeLastException
End Sub

Public Sub ApplyClientRequestHeaders(j As HttpJob)
	owner.Data_ApplyClientRequestHeaders(j)
End Sub

Public Sub SaveServerSnapshot(method As String, url As String, success As Boolean, body As String, errorMessage As String)
	owner.Data_SaveServerSnapshot(method, url, success, body, errorMessage)
End Sub

Public Sub SecondsAgoText(ticksValue As Long) As String
	Return owner.Data_SecondsAgoText(ticksValue)
End Sub

Public Sub BeginOfflineDataRefresh As Boolean
	Return policyState.BeginOfflineDataRefresh
End Sub

Public Sub EndOfflineDataRefresh(stateValue As String)
	policyState.EndOfflineDataRefresh(stateValue)
End Sub

Public Sub SetLastOfflineDataRefreshState(stateValue As String)
	policyState.LastOfflineDataRefreshState = stateValue
End Sub

Public Sub LastOfflineDataRefreshState As String
	Return policyState.LastOfflineDataRefreshState
End Sub

Public Sub SetRemoteDataReady
	policyState.SetRemoteDataReady
End Sub

Public Sub ResumePlaybackWhenServerAllows As Boolean
	Return policyState.ResumePlaybackWhenServerAllows
End Sub

Public Sub ClearResumePlaybackWhenServerAllows
	policyState.ResumePlaybackWhenServerAllows = False
End Sub

Public Sub Storage As KeyValueStore
	Return storageRef
End Sub

Public Sub TrustedSyncTimeKey As String
	Return trustedSyncTimeKeyValue
End Sub

Public Sub SaveOfflineData(data As Map)
	offlineDataRef = offlineStoreRef.SaveOfflineData(data, PlayerCodeValue, DeviceIdValue)
	If offlineDataRef.IsInitialized = False Then offlineDataRef.Initialize
End Sub

Public Sub SetOfflineData(data As Map)
	If data.IsInitialized Then
		offlineDataRef = data
	Else
		offlineDataRef.Initialize
	End If
End Sub

Public Sub OfflineData As Map
	If offlineDataRef.IsInitialized = False Then offlineDataRef.Initialize
	Return offlineDataRef
End Sub

Public Sub IsTraceUploadEnabled As Boolean
	Dim snapshot As Map = OfflineData
	If snapshot.IsInitialized = False Then Return False
	If snapshot.GetDefault("ok", False) <> True Then Return False
	If snapshot.ContainsKey("trace") Then
		Return snapshot.GetDefault("trace", False) = True
	End If
	Dim playerData As Map = snapshot.GetDefault("player", Null)
	If playerData.IsInitialized = False Then Return False
	Return playerData.ContainsKey("trace") And playerData.GetDefault("trace", False) = True
End Sub

Public Sub FlushTraceBufferAsync
	owner.Data_FlushTraceBufferAsync
End Sub

Public Sub InvalidateRelevantTrackIdsCache
	owner.Data_InvalidateRelevantTrackIdsCache
End Sub

Public Sub RefreshConnectionIndicatorState
	owner.Data_RefreshConnectionIndicatorState
End Sub

Public Sub WriteHealthSnapshot(trigger As String)
	owner.Data_WriteHealthSnapshot(trigger)
End Sub

Public Sub IsStartupSequenceInProgress As Boolean
	Return startupSequenceInProgress
End Sub

Public Sub SetStartupSequenceInProgress(value As Boolean)
	startupSequenceInProgress = value
	If value = False Then adWarmupDeferredAfterStartup = False
End Sub

Public Sub DeferAdWarmupAfterStartup
	adWarmupDeferredAfterStartup = True
End Sub

Public Sub IsAdWarmupDeferredAfterStartup As Boolean
	Return adWarmupDeferredAfterStartup
End Sub

Public Sub EnsureAdCacheSyncAsync
	owner.Data_EnsureAdCacheSyncAsync
End Sub

Public Sub EffectiveNowTicks As Long
	Dim deviceNow As Long = DateTime.Now
	Dim trustedNow As Long = storageRef.GetDefault(trustedSyncTimeKeyValue, 0)
	If trustedNow > deviceNow Then Return trustedNow
	Return deviceNow
End Sub

Public Sub IsPlaybackStarted As Boolean
	Return orchestrationStateRef.IsStarted
End Sub

Public Sub IsStoppedByUser As Boolean
	Return orchestrationStateRef.IsStoppedByUser
End Sub

Public Sub IsUserStoppedState As Boolean
	Return orchestrationStateRef.IsStarted = False And policyState.IsPlaybackPausedByPolicy = False And orchestrationStateRef.IsStoppedByUser
End Sub

Public Sub IsPolicyPauseState As Boolean
	Return policyState.IsPlaybackPausedByPolicy
End Sub

Public Sub ShouldResumeWithNewStart As Boolean
	Return orchestrationStateRef.IsStarted And IsUserStoppedState = False And IsPolicyPauseState = False And orchestrationStateRef.IsStopping = False
End Sub

Public Sub IsStopping As Boolean
	Return orchestrationStateRef.IsStopping
End Sub

Public Sub EnterStartedState
	orchestrationStateRef.EnterStartedState
End Sub

Public Sub SetStopIcon
	owner.Data_SetStopIcon
End Sub

Public Sub HideContentBlocks
	owner.Data_HideContentBlocks
End Sub

Public Sub ResumePlaybackAfterPolicyPauseAsync
	owner.Data_ResumePlaybackAfterPolicyPauseAsync
End Sub

Public Sub ClearPolicyPause
	owner.Data_ClearPolicyPause
End Sub

Public Sub HandleMessageItem(item As Map)
	owner.Data_HandleMessageItem(item)
End Sub

Public Sub SyncOfflinePlaylistMetadata As ResumableSub
	Wait For (owner.Data_SyncOfflinePlaylistMetadata) Complete (synced As Boolean)
	Return synced
End Sub

Public Sub ApplyTemporaryMode(mode As String)
	owner.Data_ApplyTemporaryMode(mode)
End Sub

Public Sub ClearPlaybackState
	owner.Data_ClearPlaybackState
End Sub

Public Sub HidePin
	owner.Data_HidePin
End Sub

Public Sub ShowMessage(text As String)
	owner.Data_ShowMessage(text)
End Sub

Public Sub ScheduleRetry(mode As String, delayMs As Int)
	owner.Data_ScheduleRetry(mode, delayMs)
End Sub

Public Sub EnterPolicyPause(reason As String, connectionMode As String)
	owner.Data_EnterPolicyPause(reason, connectionMode)
End Sub

Public Sub SetPlaybackFlowState(stateValue As String, reason As String)
	owner.Data_SetPlaybackFlowState(stateValue, reason)
End Sub

Public Sub ClearPolicyPauseAndResumeRequest
	owner.Data_ClearPolicyPauseAndResumeRequest
End Sub

Public Sub EnterUserStoppedState
	owner.Data_EnterUserStoppedState
End Sub

Public Sub SetPlayIcon
	owner.Data_SetPlayIcon
End Sub

Public Sub EnterLocalPlayback
	owner.Data_EnterLocalPlayback
End Sub

Public Sub SetMediaPathDegraded(value As Boolean)
	owner.Data_SetMediaPathDegraded(value)
End Sub

Public Sub RequestSkipQueueSnapshotRestore(reason As String)
	owner.Data_RequestSkipQueueSnapshotRestore(reason)
End Sub

Public Sub HasLocalPlaybackFallback As Boolean
	Return owner.Data_HasLocalPlaybackFallback
End Sub

Public Sub SetLocalFallbackReady(fallbackReady As Boolean)
	owner.Data_SetLocalFallbackReady(fallbackReady)
End Sub

Public Sub DisableBackgroundRefreshTimers
	owner.Data_DisableBackgroundRefreshTimers
End Sub

Public Sub ResolveRetryDelay(mode As String, delayMs As Int, localRetryMax As Int, serverRetryMax As Int, blockedRetryDelay As Int) As Int
	Return retryFallbackStateRef.ResolveRetryDelay(mode, delayMs, localRetryMax, serverRetryMax, blockedRetryDelay)
End Sub

Public Sub ClearRetryTimer
	retryTimerRef.Enabled = False
	ClearLastRetryMode
End Sub

Public Sub SetRetryInterval(value As Int)
	retryTimerRef.Interval = value
End Sub

Public Sub GetRetryInterval As Int
	Return retryTimerRef.Interval
End Sub

Public Sub IsPlaybackPausedByPolicy As Boolean
	Return policyState.IsPlaybackPausedByPolicy
End Sub

Public Sub EnableRetryTimer
	retryTimerRef.Enabled = True
End Sub

Public Sub ResetRetryDelayState(localRetryInitial As Int, serverRetryInitial As Int)
	retryFallbackStateRef.ResetRetryDelays(localRetryInitial, serverRetryInitial)
	If GetConsecutiveNetworkErrors > 0 Then TraceInfo("network", "retry сброшен", "errors=" & GetConsecutiveNetworkErrors)
	ResetConsecutiveNetworkErrors
End Sub

Public Sub ResolveDataSlotAtTicks(data As Map, targetTicks As Long) As Map
	Return dataResolverRef.ResolveDataSlotAtTicks(data, targetTicks)
End Sub

Public Sub ResolveCurrentDataSlot(data As Map) As Map
	Return dataResolverRef.ResolveCurrentDataSlot(data)
End Sub

Public Sub ResolveNextDataSlotAtTicks(data As Map, targetTicks As Long) As Map
	Return dataResolverRef.ResolveNextDataSlotAtTicks(data, targetTicks)
End Sub

Public Sub LoadCachedPlaylistMetadata(playlistId As String) As Map
	Return dataResolverRef.LoadCachedPlaylistMetadata(playlistId)
End Sub

Public Sub IsTrackCached(trackId As String) As Boolean
	Return mediaCacheRef.IsTrackCached(trackId)
End Sub
