﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Class
Version=9.85
@EndOfDesignText@
#Region Shared Files
#CustomBuildAction: folders ready, %WINDIR%\System32\Robocopy.exe,"..\..\Shared Files" "..\Files"
'Ctrl + click to sync files: ide://run?file=%WINDIR%\System32\Robocopy.exe&args=..\..\Shared+Files&args=..\Files&FilesSync=True
#End Region

Sub Class_Globals
	Private Root As B4XView
	Private xui As XUI

	Private card As B4XView
	Private headerPane As B4XView
	Private contentPane As B4XView
	Private footerPane As B4XView
	Private setupPane As B4XView
	Private playerPane As B4XView
	Private heroPane As B4XView
	Private detailPane As B4XView
	Private primaryPane As B4XView
	Private statusPane As B4XView
	Private setupHeroPane As B4XView
	Private setupDetailPane As B4XView
	Private setupPrimaryPane As B4XView
	Private setupStatusPane As B4XView
	Private playerHeroPane As B4XView
	Private playerDetailPane As B4XView
	Private playerPrimaryPane As B4XView
	Private playerStatusPane As B4XView
	Private orbitPane As B4XView
	Private playButtonPane As B4XView
	Private actionPane As B4XView
	Private confirmPane As B4XView
	Private accessCirclePane As B4XView

	Private lblTitle As B4XView
	Private lblAction As B4XView
	Private lblPlayIcon As B4XView
	Private lblStream As B4XView
	Private lblInfo As B4XView
	Private lblFooter As B4XView
	Private lblSetupMessage As B4XView

	Private txtPlayerCode As TextField
	Private txtPlayerCodeView As B4XView
	Private btnEnter As B4XView
	Private btnLogout As B4XView
	Private btnConfirmYes As B4XView
	Private btnConfirmNo As B4XView

	Private isPlaying As Boolean
	Private showingSetup As Boolean
End Sub

Public Sub Initialize
End Sub

Private Sub B4XPage_Created (Root1 As B4XView)
	Root = Root1
	BuildUi
	ApplySampleContent
	ApplyPlaybackState(False)
End Sub

Private Sub B4XPage_Resize (Width As Int, Height As Int)
	If card.IsInitialized = False Then Return
	LayoutUi(Width, Height)
End Sub

Private Sub BuildUi
	Root.Color = 0xFF0E0F11

	card = xui.CreatePanel("")
	card.SetColorAndBorder(0xFF1A1B1E, 1dip, 0x14FFFFFF, 24dip)
	Root.AddView(card, 0, 0, 0, 0)

	headerPane = xui.CreatePanel("")
	contentPane = xui.CreatePanel("")
	footerPane = xui.CreatePanel("")
	setupPane = xui.CreatePanel("")
	playerPane = xui.CreatePanel("")
	heroPane = xui.CreatePanel("")
	detailPane = xui.CreatePanel("")
	primaryPane = xui.CreatePanel("")
	statusPane = xui.CreatePanel("")
	setupHeroPane = xui.CreatePanel("")
	setupDetailPane = xui.CreatePanel("")
	setupPrimaryPane = xui.CreatePanel("")
	setupStatusPane = xui.CreatePanel("")
	playerHeroPane = xui.CreatePanel("")
	playerDetailPane = xui.CreatePanel("")
	playerPrimaryPane = xui.CreatePanel("")
	playerStatusPane = xui.CreatePanel("")
	orbitPane = xui.CreatePanel("")
	playButtonPane = xui.CreatePanel("PlayButtonPane")
	actionPane = xui.CreatePanel("ActionPane")
	confirmPane = xui.CreatePanel("")
	accessCirclePane = xui.CreatePanel("")

	card.AddView(headerPane, 0, 0, 0, 0)
	card.AddView(contentPane, 0, 0, 0, 0)
	card.AddView(footerPane, 0, 0, 0, 0)
	contentPane.AddView(setupPane, 0, 0, 0, 0)
	contentPane.AddView(playerPane, 0, 0, 0, 0)
	setupPane.AddView(setupHeroPane, 0, 0, 0, 0)
	setupPane.AddView(setupDetailPane, 0, 0, 0, 0)
	setupDetailPane.AddView(setupPrimaryPane, 0, 0, 0, 0)
	setupDetailPane.AddView(setupStatusPane, 0, 0, 0, 0)
	playerPane.AddView(playerHeroPane, 0, 0, 0, 0)
	playerPane.AddView(playerDetailPane, 0, 0, 0, 0)
	playerDetailPane.AddView(playerPrimaryPane, 0, 0, 0, 0)
	playerDetailPane.AddView(playerStatusPane, 0, 0, 0, 0)
	playerStatusPane.AddView(confirmPane, 0, 0, 0, 0)
	setupHeroPane.AddView(accessCirclePane, 0, 0, 0, 0)
	playerHeroPane.AddView(orbitPane, 0, 0, 0, 0)
	playerHeroPane.AddView(playButtonPane, 0, 0, 0, 0)
	headerPane.AddView(actionPane, 0, 0, 0, 0)

	lblTitle = CreateLabel("FON.FM 001", 12, 0xFF747B86, False, True)
	lblAction = CreateLabel(Chr(0x22EF), 22, 0xFF8E949E, False, False)
	lblPlayIcon = CreateLabel("", 48, 0xFFD0FF71, False, False)
	lblStream = CreateLabel("", 36, 0xFFD0FF71, False, True)
	lblInfo = CreateLabel("", 17, 0xFFBCC3CD, False, True)
	lblFooter = CreateLabel("FON.FM APP", 12, 0xFF747B86, False, True)
	lblSetupMessage = CreateLabel("", 17, 0xFFBCC3CD, False, True)

	txtPlayerCode.Initialize("txtPlayerCode")
	txtPlayerCodeView = txtPlayerCode
	btnEnter = CreateTextButton("ВОЙТИ", "BtnEnter")
	btnLogout = CreateTextButton("ВЫЙТИ", "BtnLogout")

	btnConfirmYes = CreateTextButton("ПОДТВЕРДИТЬ", "BtnConfirmYes")
	btnConfirmNo = CreateTextButton("ОТМЕНА", "BtnConfirmNo")

	headerPane.AddView(lblTitle, 0, 0, 0, 0)
	actionPane.AddView(lblAction, 0, 0, 0, 0)
	accessCirclePane.AddView(txtPlayerCodeView, 0, 0, 0, 0)
	playButtonPane.AddView(lblPlayIcon, 0, 0, 0, 0)
	setupPrimaryPane.AddView(btnEnter, 0, 0, 0, 0)
	setupStatusPane.AddView(lblSetupMessage, 0, 0, 0, 0)
	playerPrimaryPane.AddView(lblStream, 0, 0, 0, 0)
	playerStatusPane.AddView(lblInfo, 0, 0, 0, 0)
	playerStatusPane.AddView(btnLogout, 0, 0, 0, 0)
	footerPane.AddView(lblFooter, 0, 0, 0, 0)
	confirmPane.AddView(btnConfirmYes, 0, 0, 0, 0)
	confirmPane.AddView(btnConfirmNo, 0, 0, 0, 0)

	accessCirclePane.SetColorAndBorder(0xFF14171C, 4dip, 0x33FFFFFF, 999dip)
	playButtonPane.SetColorAndBorder(xui.Color_Transparent, 4dip, 0x33FFFFFF, 999dip)
	orbitPane.SetColorAndBorder(xui.Color_Transparent, 2dip, 0x00D0FF71, 999dip)
	actionPane.SetColorAndBorder(xui.Color_Transparent, 0, xui.Color_Transparent, 8dip)
	confirmPane.Visible = False
	showingSetup = True

	SetPaneStyle(card, "-fx-background-radius: 24; -fx-border-radius: 24;")
	SetPaneStyle(playButtonPane, "-fx-cursor: hand;")
	SetPaneStyle(actionPane, "-fx-cursor: hand;")
	SetPaneStyle(accessCirclePane, "-fx-background-radius: 999; -fx-border-radius: 999;")
	SetPaneStyle(txtPlayerCodeView, "-fx-background-color: transparent; -fx-text-fill: " & ColorToCss(0xFFE0E4EA) & "; -fx-prompt-text-fill: " & ColorToCss(0xFF8E949E) & "; -fx-alignment: center; -fx-background-insets: 0; -fx-border-width: 0;")
	txtPlayerCode.PromptText = "КОД"

	LayoutUi(Root.Width, Root.Height)
End Sub

Private Sub LayoutUi(Width As Int, Height As Int)
	Dim safeWidth As Int = Max(Width, 320dip)
	Dim safeHeight As Int = Max(Height, 420dip)
	Dim outerPad As Int = ScaleValue(safeWidth, 12dip, 20dip, 20dip)
	Dim horizontalPad As Int = ScaleValue(safeWidth, 12dip, 16dip, 24dip)
	Dim sectionGap As Int = ScaleValue(safeWidth, 24dip, 32dip, 48dip)
	Dim contentGap As Int = ScaleValue(safeWidth, 8dip, 12dip, 12dip)
	Dim headerHeight As Int = ScaleValue(safeWidth, 56dip, 64dip, 72dip)
	Dim footerHeight As Int = headerHeight
	Dim cardWidth As Int = Min(620dip, safeWidth - outerPad * 2)
	Dim preferredHeight As Int = Max(400dip, safeHeight - outerPad * 2)
	Dim cardHeight As Int = Min(preferredHeight, safeHeight - 8dip)
	Dim cardLeft As Int = (safeWidth - cardWidth) / 2
	Dim cardTop As Int = (safeHeight - cardHeight) / 2

	card.SetLayoutAnimated(0, cardLeft, cardTop, cardWidth, cardHeight)

	headerPane.SetLayoutAnimated(0, 0, 0, cardWidth, headerHeight)
	contentPane.SetLayoutAnimated(0, 0, headerHeight + sectionGap / 2, cardWidth, cardHeight - headerHeight - footerHeight - sectionGap)
	footerPane.SetLayoutAnimated(0, 0, cardHeight - footerHeight, cardWidth, footerHeight)

	actionPane.SetLayoutAnimated(0, cardWidth - horizontalPad - 32dip, (headerHeight - 32dip) / 2, 32dip, 32dip)
	lblAction.SetLayoutAnimated(0, 0, 0, actionPane.Width, actionPane.Height)
	lblTitle.SetLayoutAnimated(0, horizontalPad + 32dip + contentGap, 0, cardWidth - (horizontalPad + 32dip + contentGap) * 2, headerHeight)

	setupPane.SetLayoutAnimated(0, 0, 0, contentPane.Width, contentPane.Height)
	playerPane.SetLayoutAnimated(0, 0, 0, contentPane.Width, contentPane.Height)

	Dim contentHeight As Int = contentPane.Height
	Dim heroHeight As Int = Max(160dip, (contentHeight - sectionGap) / 2)
	Dim detailHeight As Int = Max(120dip, contentHeight - heroHeight - sectionGap)

	setupHeroPane.SetLayoutAnimated(0, horizontalPad, 0, cardWidth - horizontalPad * 2, heroHeight)
	setupDetailPane.SetLayoutAnimated(0, horizontalPad, heroHeight + sectionGap, cardWidth - horizontalPad * 2, detailHeight)
	playerHeroPane.SetLayoutAnimated(0, horizontalPad, 0, cardWidth - horizontalPad * 2, heroHeight)
	playerDetailPane.SetLayoutAnimated(0, horizontalPad, heroHeight + sectionGap, cardWidth - horizontalPad * 2, detailHeight)

	Dim controlSize As Int = ScaleValue(safeWidth, 144dip, 160dip, 168dip)
	Dim inputSize As Int = controlSize
	Dim inputLeft As Int = (setupHeroPane.Width - inputSize) / 2
	Dim inputTop As Int = Max(0, (setupHeroPane.Height - inputSize) / 2)
	accessCirclePane.SetLayoutAnimated(0, inputLeft, inputTop, inputSize, inputSize)
	txtPlayerCodeView.SetLayoutAnimated(0, 18dip, (inputSize - 32dip) / 2, inputSize - 36dip, 32dip)

	Dim orbitSize As Int = controlSize + 20dip
	Dim orbitLeft As Int = (playerHeroPane.Width - orbitSize) / 2
	Dim controlLeft As Int = (playerHeroPane.Width - controlSize) / 2
	Dim controlTop As Int = Max(0, (playerHeroPane.Height - controlSize) / 2)
	orbitPane.SetLayoutAnimated(0, orbitLeft, controlTop - 10dip, orbitSize, orbitSize)
	playButtonPane.SetLayoutAnimated(0, controlLeft, controlTop, controlSize, controlSize)
	lblPlayIcon.SetLayoutAnimated(0, 0, 0, controlSize, controlSize)

	setupPrimaryPane.SetLayoutAnimated(0, 0, 0, setupDetailPane.Width, Max(56dip, setupDetailPane.Height * 0.38))
	setupStatusPane.SetLayoutAnimated(0, 0, setupPrimaryPane.Height + contentGap, setupDetailPane.Width, setupDetailPane.Height - setupPrimaryPane.Height - contentGap)
	btnEnter.SetLayoutAnimated(0, Max(0, (setupPrimaryPane.Width - 132dip) / 2), Max(0, (setupPrimaryPane.Height - 44dip) / 2), 132dip, 44dip)
	lblSetupMessage.SetLayoutAnimated(0, 0, 0, setupStatusPane.Width, setupStatusPane.Height)

	playerPrimaryPane.SetLayoutAnimated(0, 0, 0, playerDetailPane.Width, Max(56dip, playerDetailPane.Height * 0.32))
	playerStatusPane.SetLayoutAnimated(0, 0, playerPrimaryPane.Height + contentGap, playerDetailPane.Width, playerDetailPane.Height - playerPrimaryPane.Height - contentGap)
	lblStream.SetLayoutAnimated(0, 0, 0, playerPrimaryPane.Width, playerPrimaryPane.Height)

	Dim infoReservedHeight As Int = 0
	If confirmPane.Visible Then infoReservedHeight = 84dip
	Dim playerButtonsTop As Int = 56dip
	Dim infoHeight As Int = Max(54dip, playerStatusPane.Height - infoReservedHeight - playerButtonsTop)
	lblInfo.SetLayoutAnimated(0, 0, 0, playerStatusPane.Width, infoHeight)
	btnLogout.SetLayoutAnimated(0, Max(0, (playerStatusPane.Width - 132dip) / 2), infoHeight + contentGap, 132dip, 44dip)
	If confirmPane.Visible Then
		confirmPane.SetLayoutAnimated(0, 0, playerStatusPane.Height - 72dip, playerStatusPane.Width, 72dip)
	Else
		confirmPane.SetLayoutAnimated(0, 0, playerStatusPane.Height, playerStatusPane.Width, 0)
	End If

	Dim buttonWidth As Int = 132dip
	Dim buttonsGap As Int = 12dip
	Dim totalButtonsWidth As Int = buttonWidth * 2 + buttonsGap
	Dim buttonsLeft As Int = Max(0, (confirmPane.Width - totalButtonsWidth) / 2)
	btnConfirmYes.SetLayoutAnimated(0, buttonsLeft, 14dip, buttonWidth, 44dip)
	btnConfirmNo.SetLayoutAnimated(0, buttonsLeft + buttonWidth + buttonsGap, 14dip, buttonWidth, 44dip)

	lblFooter.SetLayoutAnimated(0, horizontalPad, 0, cardWidth - horizontalPad * 2, footerHeight)
	UpdateResponsiveStyles(safeWidth)
	UpdateVisibleMode
End Sub

Private Sub UpdateResponsiveStyles(AvailableWidth As Int)
	Dim small As Boolean = AvailableWidth <= 420dip
	Dim medium As Boolean = AvailableWidth <= 720dip
	Dim streamFontSize As Float
	Dim infoFontSize As Float
	Dim playFontSize As Float
	Dim cardRadius As Int

	If small Then
		streamFontSize = 28
		infoFontSize = 16
		playFontSize = 42
		cardRadius = 16dip
	Else If medium Then
		streamFontSize = 32
		infoFontSize = 17
		playFontSize = 48
		cardRadius = 20dip
	Else
		streamFontSize = 38
		infoFontSize = 17
		playFontSize = 48
		cardRadius = 24dip
	End If

	lblStream.Font = xui.CreateDefaultFont(streamFontSize)
	lblInfo.Font = xui.CreateDefaultFont(infoFontSize)
	lblTitle.Font = xui.CreateDefaultFont(12)
	lblFooter.Font = xui.CreateDefaultFont(12)
	lblAction.Font = xui.CreateDefaultFont(22)
	lblPlayIcon.Font = xui.CreateDefaultBoldFont(playFontSize)

	card.SetColorAndBorder(0xFF1A1B1E, 1dip, 0x14FFFFFF, cardRadius)
	playButtonPane.SetColorAndBorder(xui.Color_Transparent, 4dip, 0x33FFFFFF, 999dip)
End Sub

Private Sub ApplySampleContent
	lblTitle.Text = "FON.FM PLAYER"
	lblStream.Text = "FON.FM LIVE"
	lblInfo.Text = "Название потока и информация о текущем треке отображаются здесь в две строки."
	lblSetupMessage.Text = "Введите код плеера и нажмите ВОЙТИ."
	lblFooter.Text = "FON.FM APP"
End Sub

Private Sub ApplyPlaybackState(Playing As Boolean)
	isPlaying = Playing
	If isPlaying Then
		lblPlayIcon.Text = "■"
		SetLabelStyle(lblPlayIcon, "-fx-alignment: center; -fx-text-fill: " & ColorToCss(0xFFD0FF71) & ";")
		orbitPane.SetColorAndBorder(xui.Color_Transparent, 2dip, 0x66D0FF71, 999dip)
		playButtonPane.SetColorAndBorder(0x08FFFFFF, 4dip, 0x55FFFFFF, 999dip)
	Else
		lblPlayIcon.Text = "▶"
		SetLabelStyle(lblPlayIcon, "-fx-alignment: center; -fx-text-fill: " & ColorToCss(0xFFD0FF71) & ";")
		orbitPane.SetColorAndBorder(xui.Color_Transparent, 2dip, 0x00D0FF71, 999dip)
		playButtonPane.SetColorAndBorder(xui.Color_Transparent, 4dip, 0x33FFFFFF, 999dip)
	End If
End Sub

Private Sub PlayButtonPane_Click
	If isPlaying Then
		ApplyPlaybackState(False)
	Else
		ApplyPlaybackState(True)
	End If
End Sub

Private Sub ActionPane_Click
	If showingSetup Then
		showingSetup = False
	Else
		showingSetup = True
	End If
	confirmPane.Visible = False
	UpdateVisibleMode
	LayoutUi(Root.Width, Root.Height)
End Sub

Private Sub BtnEnter_Click
	showingSetup = False
	UpdateVisibleMode
	LayoutUi(Root.Width, Root.Height)
End Sub

Private Sub BtnLogout_Click
	showingSetup = True
	confirmPane.Visible = False
	UpdateVisibleMode
	LayoutUi(Root.Width, Root.Height)
End Sub

Private Sub BtnConfirmYes_Click
	lblInfo.Text = "Подтверждение показано как визуальный аналог нижней панели web-плеера."
End Sub

Private Sub BtnConfirmNo_Click
	confirmPane.Visible = False
	LayoutUi(Root.Width, Root.Height)
End Sub

Private Sub CreateLabel(Text As String, FontSize As Float, TextColor As Int, Bold As Boolean, WrapText As Boolean) As B4XView
	Dim lbl As Label
	lbl.Initialize("")
	lbl.Text = Text
	lbl.WrapText = WrapText
	Dim xlbl As B4XView = lbl
	If Bold Then
		xlbl.Font = xui.CreateDefaultBoldFont(FontSize)
	Else
		xlbl.Font = xui.CreateDefaultFont(FontSize)
	End If
	xlbl.SetTextAlignment("CENTER", "CENTER")
	SetLabelStyle(xlbl, "-fx-alignment: center; -fx-text-fill: " & ColorToCss(TextColor) & ";")
	Return xlbl
End Sub

Private Sub CreateTextButton(Text As String, EventName As String) As B4XView
	Dim btn As Button
	btn.Initialize(EventName)
	Dim xbtn As B4XView = btn
	xbtn.Text = Text
	xbtn.Font = xui.CreateDefaultFont(12)
	SetPaneStyle(xbtn, "-fx-background-color: transparent; -fx-border-color: rgba(255,255,255,0.12); -fx-border-radius: 12; -fx-background-radius: 12; -fx-text-fill: " & ColorToCss(0xFFE0E4EA) & ";")
	Return xbtn
End Sub

Private Sub SetPaneStyle(View As B4XView, Style As String)
	Dim jo As JavaObject = View
	jo.RunMethod("setStyle", Array(Style))
End Sub

Private Sub SetLabelStyle(View As B4XView, Style As String)
	Dim jo As JavaObject = View
	jo.RunMethod("setStyle", Array(Style))
End Sub

Private Sub ScaleValue(AvailableWidth As Int, SmallValue As Int, MediumValue As Int, LargeValue As Int) As Int
	If AvailableWidth <= 420dip Then Return SmallValue
	If AvailableWidth <= 720dip Then Return MediumValue
	Return LargeValue
End Sub

Private Sub UpdateVisibleMode
	setupPane.Visible = showingSetup
	If showingSetup Then
		playerPane.Visible = False
	Else
		playerPane.Visible = True
	End If
	If showingSetup Then
		lblTitle.Text = "FON.FM PLAYER"
		lblAction.Text = Chr(0x22EF)
	Else
		lblTitle.Text = "FON.FM PLAYER"
		lblAction.Text = Chr(0x22EF)
	End If
End Sub

Private Sub ColorToCss(Color As Int) As String
	Dim unsignedColor As Long = Bit.And(0xFFFFFFFF, Color)
	Dim rgb As Int = Bit.And(unsignedColor, 0xFFFFFF)
	Return "#" & Bit.ToHexString(rgb)
End Sub
