﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Class
Version=10.5
@EndOfDesignText@

' Контракт локального состояния player.
' Coordinator / network worker общаются с приложением через этот store, а не напрямую с page internals.

Sub Class_Globals
	Private owner As B4XMainPage
	Private consecutiveNetworkErrors As Int
	Private lastRetryMode As String
	Private lastDataOkAt As Long
	Private lastHistoryOkAt As Long
End Sub

Public Sub Initialize(target As B4XMainPage)
	owner = target
End Sub

Public Sub IncrementNetworkErrorCount
	consecutiveNetworkErrors = consecutiveNetworkErrors + 1
End Sub

Public Sub ResetConsecutiveNetworkErrors
	consecutiveNetworkErrors = 0
End Sub

Public Sub GetConsecutiveNetworkErrors As Int
	Return consecutiveNetworkErrors
End Sub

Public Sub SetLastRetryMode(mode As String)
	lastRetryMode = mode
End Sub

Public Sub GetLastRetryMode As String
	Return lastRetryMode
End Sub

Public Sub ClearLastRetryMode
	lastRetryMode = ""
End Sub

Public Sub SetLastDataOkNow
	lastDataOkAt = DateTime.Now
End Sub

Public Sub GetLastDataOkAt As Long
	Return lastDataOkAt
End Sub

Public Sub SetLastHistoryOkNow
	lastHistoryOkAt = DateTime.Now
End Sub

Public Sub GetLastHistoryOkAt As Long
	Return lastHistoryOkAt
End Sub

Public Sub PlayerCodeValue As String
	Return owner.PlayerCodeValue
End Sub

Public Sub DeviceIdValue As String
	Return owner.DeviceIdValue
End Sub

Public Sub TimezoneOffsetMinutesValue As Int
	Return owner.TimezoneOffsetMinutesValue
End Sub

Public Sub ClientOsNameValue As String
	Return owner.ClientOsNameValue
End Sub

Public Sub ServiceCheckUrlValue As String
	Return owner.ServiceCheckUrlValue
End Sub

Public Sub DataUrlValue As String
	Return owner.DataUrlValue
End Sub

Public Sub NextUrlValue As String
	Return owner.NextUrlValue
End Sub

Public Sub ClaimUrlValue As String
	Return owner.ClaimUrlValue
End Sub

Public Sub MessageValue(key As String) As String
	Return owner.Data_MessageValue(key)
End Sub

Public Sub TraceLog(message As String)
	owner.Data_TraceLog(message)
End Sub

Public Sub TraceInfo(category As String, message As String, details As String)
	owner.Data_TraceInfo(category, message, details)
End Sub

Public Sub TraceWarn(category As String, message As String, details As String)
	owner.Data_TraceWarn(category, message, details)
End Sub

Public Sub ConsumeLastException
	owner.Data_ConsumeLastException
End Sub

Public Sub ApplyClientRequestHeaders(j As HttpJob)
	owner.Data_ApplyClientRequestHeaders(j)
End Sub

Public Sub SaveServerSnapshot(method As String, url As String, success As Boolean, body As String, errorMessage As String)
	owner.Data_SaveServerSnapshot(method, url, success, body, errorMessage)
End Sub

Public Sub SecondsAgoText(ticksValue As Long) As String
	Return owner.Data_SecondsAgoText(ticksValue)
End Sub

Public Sub BeginOfflineDataRefresh As Boolean
	Return owner.Data_BeginOfflineDataRefresh
End Sub

Public Sub EndOfflineDataRefresh(stateValue As String)
	owner.Data_EndOfflineDataRefresh(stateValue)
End Sub

Public Sub SetLastOfflineDataRefreshState(stateValue As String)
	owner.Data_SetLastOfflineDataRefreshState(stateValue)
End Sub

Public Sub LastOfflineDataRefreshState As String
	Return owner.Data_LastOfflineDataRefreshState
End Sub

Public Sub SetRemoteDataReady
	owner.Data_SetRemoteDataReady
End Sub

Public Sub ResumePlaybackWhenServerAllows As Boolean
	Return owner.Data_ResumePlaybackWhenServerAllows
End Sub

Public Sub ClearResumePlaybackWhenServerAllows
	owner.Data_ClearResumePlaybackWhenServerAllows
End Sub

Public Sub Storage As KeyValueStore
	Return owner.Data_Storage
End Sub

Public Sub TrustedSyncTimeKey As String
	Return owner.Data_TrustedSyncTimeKey
End Sub

Public Sub SaveOfflineData(data As Map)
	owner.Data_SaveOfflineData(data)
End Sub

Public Sub OfflineData As Map
	Return owner.Data_OfflineData
End Sub

Public Sub IsTraceUploadEnabled As Boolean
	Return owner.Data_IsTraceUploadEnabled
End Sub

Public Sub FlushTraceBufferAsync
	owner.Data_FlushTraceBufferAsync
End Sub

Public Sub InvalidateRelevantTrackIdsCache
	owner.Data_InvalidateRelevantTrackIdsCache
End Sub

Public Sub RefreshConnectionIndicatorState
	owner.Data_RefreshConnectionIndicatorState
End Sub

Public Sub WriteHealthSnapshot(trigger As String)
	owner.Data_WriteHealthSnapshot(trigger)
End Sub

Public Sub IsStartupSequenceInProgress As Boolean
	Return owner.Data_IsStartupSequenceInProgress
End Sub

Public Sub DeferAdWarmupAfterStartup
	owner.Data_DeferAdWarmupAfterStartup
End Sub

Public Sub EnsureAdCacheSyncAsync
	owner.Data_EnsureAdCacheSyncAsync
End Sub

Public Sub EffectiveNowTicks As Long
	Return owner.Data_EffectiveNowTicks
End Sub

Public Sub IsPlaybackStarted As Boolean
	Return owner.Data_IsPlaybackStarted
End Sub

Public Sub IsStoppedByUser As Boolean
	Return owner.Data_IsStoppedByUser
End Sub

Public Sub IsUserStoppedState As Boolean
	Return owner.Data_IsUserStoppedState
End Sub

Public Sub IsPolicyPauseState As Boolean
	Return owner.Data_IsPolicyPauseState
End Sub

Public Sub ShouldResumeWithNewStart As Boolean
	Return owner.Data_ShouldResumeWithNewStart
End Sub

Public Sub IsStopping As Boolean
	Return owner.Data_IsStopping
End Sub

Public Sub EnterStartedState
	owner.Data_EnterStartedState
End Sub

Public Sub SetStopIcon
	owner.Data_SetStopIcon
End Sub

Public Sub HideContentBlocks
	owner.Data_HideContentBlocks
End Sub

Public Sub ResumePlaybackAfterPolicyPauseAsync
	owner.Data_ResumePlaybackAfterPolicyPauseAsync
End Sub

Public Sub ClearPolicyPause
	owner.Data_ClearPolicyPause
End Sub

Public Sub HandleMessageItem(item As Map)
	owner.Data_HandleMessageItem(item)
End Sub

Public Sub SyncOfflinePlaylistMetadata As ResumableSub
	Wait For (owner.Data_SyncOfflinePlaylistMetadata) Complete (synced As Boolean)
	Return synced
End Sub

Public Sub ApplyTemporaryMode(mode As String)
	owner.Data_ApplyTemporaryMode(mode)
End Sub

Public Sub ClearPlaybackState
	owner.Data_ClearPlaybackState
End Sub

Public Sub HidePin
	owner.Data_HidePin
End Sub

Public Sub ShowMessage(text As String)
	owner.Data_ShowMessage(text)
End Sub

Public Sub ScheduleRetry(mode As String, delayMs As Int)
	owner.Data_ScheduleRetry(mode, delayMs)
End Sub

Public Sub EnterPolicyPause(reason As String, connectionMode As String)
	owner.Data_EnterPolicyPause(reason, connectionMode)
End Sub

Public Sub SetPlaybackFlowState(stateValue As String, reason As String)
	owner.Data_SetPlaybackFlowState(stateValue, reason)
End Sub

Public Sub ClearPolicyPauseAndResumeRequest
	owner.Data_ClearPolicyPauseAndResumeRequest
End Sub

Public Sub EnterUserStoppedState
	owner.Data_EnterUserStoppedState
End Sub

Public Sub SetPlayIcon
	owner.Data_SetPlayIcon
End Sub

Public Sub EnterLocalPlayback
	owner.Data_EnterLocalPlayback
End Sub

Public Sub SetMediaPathDegraded(value As Boolean)
	owner.Data_SetMediaPathDegraded(value)
End Sub

Public Sub RequestSkipQueueSnapshotRestore(reason As String)
	owner.Data_RequestSkipQueueSnapshotRestore(reason)
End Sub

Public Sub HasLocalPlaybackFallback As Boolean
	Return owner.Data_HasLocalPlaybackFallback
End Sub

Public Sub SetLocalFallbackReady(fallbackReady As Boolean)
	owner.Data_SetLocalFallbackReady(fallbackReady)
End Sub

Public Sub DisableBackgroundRefreshTimers
	owner.Data_DisableBackgroundRefreshTimers
End Sub

Public Sub ResolveRetryDelay(mode As String, delayMs As Int, localRetryMax As Int, serverRetryMax As Int, blockedRetryDelay As Int) As Int
	Return owner.Data_ResolveRetryDelay(mode, delayMs, localRetryMax, serverRetryMax, blockedRetryDelay)
End Sub

Public Sub ClearRetryTimer
	owner.Data_ClearRetryTimer
End Sub

Public Sub SetRetryInterval(value As Int)
	owner.Data_SetRetryInterval(value)
End Sub

Public Sub GetRetryInterval As Int
	Return owner.Data_GetRetryInterval
End Sub

Public Sub IsPlaybackPausedByPolicy As Boolean
	Return owner.Data_IsPlaybackPausedByPolicy
End Sub

Public Sub EnableRetryTimer
	owner.Data_EnableRetryTimer
End Sub

Public Sub ResetRetryDelayState(localRetryInitial As Int, serverRetryInitial As Int)
	owner.Data_ResetRetryDelayState(localRetryInitial, serverRetryInitial)
End Sub

Public Sub ResolveDataSlotAtTicks(data As Map, targetTicks As Long) As Map
	Return owner.Data_ResolveDataSlotAtTicks(data, targetTicks)
End Sub

Public Sub ResolveCurrentDataSlot(data As Map) As Map
	Return owner.Data_ResolveCurrentDataSlot(data)
End Sub

Public Sub ResolveNextDataSlotAtTicks(data As Map, targetTicks As Long) As Map
	Return owner.Data_ResolveNextDataSlotAtTicks(data, targetTicks)
End Sub

Public Sub LoadCachedPlaylistMetadata(playlistId As String) As Map
	Return owner.Data_LoadCachedPlaylistMetadata(playlistId)
End Sub

Public Sub IsTrackCached(trackId As String) As Boolean
	Return owner.Data_IsTrackCached(trackId)
End Sub
