﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Class
Version=9.85
@EndOfDesignText@
#Region Shared Files
#CustomBuildAction: folders ready, %WINDIR%\System32\Robocopy.exe,"..\..\Shared Files" "..\Files"
'Ctrl + click to sync files: ide://run?file=%WINDIR%\System32\Robocopy.exe&args=..\..\Shared+Files&args=..\Files&FilesSync=True
#End Region

Sub Class_Globals
	Private Const PLAYER_BASE_URL As String = "https://play.fon.fm/meta"
	Private Const NEXT_BASE_URL As String = "https://play.fon.fm/next"
	Private Const CLAIM_BASE_URL As String = "https://play.fon.fm/claim"
	Private Const HISTORY_BASE_URL As String = "https://play.fon.fm/history"
	Private Const CONNECTIVITY_CHECK_URL As String = "https://radiosparx.ru/img/logo-dark.svg"
	Private Const APP_VERSION As String = "1.0.1"
	Private Const PREFETCH_SECONDS As Int = 10
	Private Const STOP_FADE_MS As Int = 3000
	Private Const HISTORY_LOG_DELAY_MS As Int = 15000
	Private Const FETCH_TIMEOUT_MS As Int = 8000
	Private Const CONNECTIVITY_CHECK_TIMEOUT_MS As Int = 5000
	Private Const PAUSE_RETRY_DELAY As Int = 300000
	Private Const OFFLINE_RETRY_DELAY_INITIAL As Int = 5000
	Private Const OFFLINE_RETRY_DELAY_MAX As Int = 30000
	Private Const SERVER_RETRY_DELAY_INITIAL As Int = 10000
	Private Const SERVER_RETRY_DELAY_MAX As Int = 60000
	Private Const BLOCKED_RETRY_DELAY As Int = 60000

	Private Root As B4XView
	Private xui As XUI
	Private storageDir As String
	Private storageFile As String = "player_state.json"

	Private card As B4XView
	Private headerPane As B4XView
	Private headerActionPane As B4XView
	Private contentPane As B4XView
	Private footerPane As B4XView
	Private setupPane As B4XView
	Private playerPane As B4XView
	Private setupHeroPane As B4XView
	Private setupDetailPane As B4XView
	Private setupPrimaryPane As B4XView
	Private setupStatusPane As B4XView
	Private playerHeroPane As B4XView
	Private playerDetailPane As B4XView
	Private playerPrimaryPane As B4XView
	Private playerStatusPane As B4XView
	Private orbitPane As B4XView
	Private playButtonPane As B4XView
	Private confirmPane As B4XView
	Private accessCirclePane As B4XView

	Private lblHeader As B4XView
	Private lblHeaderAction As B4XView
	Private lblPlayIcon As B4XView
	Private lblStream As B4XView
	Private lblInfo As B4XView
	Private lblFooter As B4XView
	Private lblSetupMessage As B4XView

	Private txtPlayerCode As TextField
	Private txtPlayerCodeView As B4XView
	Private btnSetupSubmit As B4XView
	Private btnConfirmYes As B4XView
	Private btnConfirmNo As B4XView

	Private audio As AudioPlayer
	Private storage As Map
	Private playQueue As List
	Private messages As Map

	Private retryTimer As Timer
	Private breakTimer As Timer
	Private historyTimer As Timer

	Private playerCode As String
	Private deviceId As String
	Private appScreenMode As String
	Private playerLevel As Double = 1
	Private nextStartMode As String
	Private currentTrackUrl As String
	Private currentMediaType As String
	Private historyItem As Map

	Private isStarted As Boolean
	Private isStoppedByUser As Boolean = True
	Private isStopping As Boolean
	Private isQueueTransitioning As Boolean
	Private prefetchDone As Boolean

	Private offlineRetryDelay As Int = OFFLINE_RETRY_DELAY_INITIAL
	Private serverRetryDelay As Int = SERVER_RETRY_DELAY_INITIAL
	Private playlistIndex As Int = -1
	Private scheduledBreakAt As Long = -1
End Sub

Private Type FetchResult (Success As Boolean, Kind As String, Data As Object, ErrorMessage As String)

Public Sub Initialize
End Sub

Private Sub B4XPage_Created (Root1 As B4XView)
	Root = Root1
	Root.Color = 0xFF0E0F11
	InitSettings
	InitState
	BuildUi
	audio.Initialize("Audio", Me)
	ShowInitialScreen
End Sub

Private Sub B4XPage_Resize (Width As Int, Height As Int)
	If card.IsInitialized = False Then Return
	LayoutUi(Width, Height)
End Sub

Private Sub InitSettings
	messages.Initialize
	messages.Put("offline", "Требуется интернет")
	messages.Put("server_wait", "Временная остановка")
	messages.Put("idle", "Перерыв...")
	messages.Put("idle_until", "Перерыв до {time}")
	messages.Put("blocked", "Плеер заблокирован")
	messages.Put("idle_stream", "Запусти поток")
	messages.Put("player_required", "Не указан плеер")
	messages.Put("device_required", "Не указано устройство")
	messages.Put("device_busy", "Плеер играет на другом устройстве. Играть здесь?")
	messages.Put("device_confirm_yes", "Да")
	messages.Put("device_confirm_no", "Нет")
	messages.Put("not_found", "Плеер не найден")
	messages.Put("player_updated", "Плеер обновлен")
	messages.Put("player_reloading", "Обновление…")
	messages.Put("ad_label", "Реклама")
	messages.Put("setup_title", "Введите код плеера")
	messages.Put("setup_placeholder", "abc12")
	messages.Put("setup_submit", "Войти")
	messages.Put("setup_invalid", "Введите код из 5 символов")
	messages.Put("logout", "Выйти")
	messages.Put("settings_open", "Настройки")
	messages.Put("settings_close", "Закрыть")
	messages.Put("settings_thanks", "Спасибо!")
End Sub

Private Sub InitState
	storageDir = File.DirData("fonfm")
	storage = LoadStorage
	deviceId = GetOrCreateDeviceId
	playerCode = NormalizePlayerCode(storage.GetDefault("player_code", ""))
	playQueue.Initialize
	retryTimer.Initialize("RetryTimer", SERVER_RETRY_DELAY_INITIAL)
	breakTimer.Initialize("BreakTimer", 1000)
	historyTimer.Initialize("HistoryTimer", HISTORY_LOG_DELAY_MS)
	historyItem.Initialize
End Sub

Private Sub BuildUi
	card = xui.CreatePanel("")
	headerPane = xui.CreatePanel("")
	headerActionPane = xui.CreatePanel("HeaderActionPane")
	contentPane = xui.CreatePanel("")
	footerPane = xui.CreatePanel("")
	setupPane = xui.CreatePanel("")
	playerPane = xui.CreatePanel("")
	setupHeroPane = xui.CreatePanel("")
	setupDetailPane = xui.CreatePanel("")
	setupPrimaryPane = xui.CreatePanel("")
	setupStatusPane = xui.CreatePanel("")
	playerHeroPane = xui.CreatePanel("")
	playerDetailPane = xui.CreatePanel("")
	playerPrimaryPane = xui.CreatePanel("")
	playerStatusPane = xui.CreatePanel("")
	orbitPane = xui.CreatePanel("")
	playButtonPane = xui.CreatePanel("PlayButtonPane")
	confirmPane = xui.CreatePanel("")
	accessCirclePane = xui.CreatePanel("")

	card.SetColorAndBorder(0xFF1A1B1E, 1dip, 0x14FFFFFF, 24dip)
	accessCirclePane.SetColorAndBorder(0xFF14171C, 4dip, 0x33FFFFFF, 999dip)
	playButtonPane.SetColorAndBorder(xui.Color_Transparent, 4dip, 0x33FFFFFF, 999dip)
	orbitPane.SetColorAndBorder(xui.Color_Transparent, 2dip, 0x00D0FF71, 999dip)
	headerActionPane.SetColorAndBorder(xui.Color_Transparent, 0, xui.Color_Transparent, 8dip)

	lblHeader = CreateLabel("", 12, 0xFF747B86, False, True)
	lblHeaderAction = CreateLabel(Chr(0x22EF), 22, 0xFF8E949E, False, False)
	lblPlayIcon = CreateLabel("▶", 48, 0xFFD0FF71, True, False)
	lblStream = CreateLabel("", 36, 0xFFD0FF71, False, True)
	lblInfo = CreateLabel("", 17, 0xFFBCC3CD, False, True)
	lblFooter = CreateLabel("FON.FM APP " & APP_VERSION, 12, 0xFF747B86, False, True)
	lblSetupMessage = CreateLabel("", 17, 0xFFBCC3CD, False, True)

	txtPlayerCode.Initialize("txtPlayerCode")
	txtPlayerCodeView = txtPlayerCode
	btnSetupSubmit = CreateTextButton(MessageValue("setup_submit"), "BtnSetupSubmit")
	btnConfirmYes = CreateTextButton(MessageValue("device_confirm_yes"), "BtnConfirmYes")
	btnConfirmNo = CreateTextButton(MessageValue("device_confirm_no"), "BtnConfirmNo")

	Root.AddView(card, 0, 0, 0, 0)
	card.AddView(headerPane, 0, 0, 0, 0)
	card.AddView(contentPane, 0, 0, 0, 0)
	card.AddView(footerPane, 0, 0, 0, 0)
	headerPane.AddView(lblHeader, 0, 0, 0, 0)
	headerPane.AddView(headerActionPane, 0, 0, 0, 0)
	headerActionPane.AddView(lblHeaderAction, 0, 0, 0, 0)
	contentPane.AddView(setupPane, 0, 0, 0, 0)
	contentPane.AddView(playerPane, 0, 0, 0, 0)
	footerPane.AddView(lblFooter, 0, 0, 0, 0)

	setupPane.AddView(setupHeroPane, 0, 0, 0, 0)
	setupPane.AddView(setupDetailPane, 0, 0, 0, 0)
	setupHeroPane.AddView(accessCirclePane, 0, 0, 0, 0)
	accessCirclePane.AddView(txtPlayerCodeView, 0, 0, 0, 0)
	setupDetailPane.AddView(setupPrimaryPane, 0, 0, 0, 0)
	setupDetailPane.AddView(setupStatusPane, 0, 0, 0, 0)
	setupPrimaryPane.AddView(btnSetupSubmit, 0, 0, 0, 0)
	setupStatusPane.AddView(lblSetupMessage, 0, 0, 0, 0)

	playerPane.AddView(playerHeroPane, 0, 0, 0, 0)
	playerPane.AddView(playerDetailPane, 0, 0, 0, 0)
	playerHeroPane.AddView(orbitPane, 0, 0, 0, 0)
	playerHeroPane.AddView(playButtonPane, 0, 0, 0, 0)
	playButtonPane.AddView(lblPlayIcon, 0, 0, 0, 0)
	playerDetailPane.AddView(playerPrimaryPane, 0, 0, 0, 0)
	playerDetailPane.AddView(playerStatusPane, 0, 0, 0, 0)
	playerPrimaryPane.AddView(lblStream, 0, 0, 0, 0)
	playerStatusPane.AddView(lblInfo, 0, 0, 0, 0)
	playerStatusPane.AddView(confirmPane, 0, 0, 0, 0)
	confirmPane.AddView(btnConfirmYes, 0, 0, 0, 0)
	confirmPane.AddView(btnConfirmNo, 0, 0, 0, 0)

	SetPaneStyle(card, "-fx-background-radius: 24; -fx-border-radius: 24;")
	SetPaneStyle(headerActionPane, "-fx-cursor: hand;")
	SetPaneStyle(playButtonPane, "-fx-cursor: hand;")
	SetPaneStyle(accessCirclePane, "-fx-background-radius: 999; -fx-border-radius: 999;")
	SetPaneStyle(txtPlayerCodeView, "-fx-background-color: transparent; -fx-text-fill: " & ColorToCss(0xFFE0E4EA) & "; -fx-prompt-text-fill: " & ColorToCss(0xFF8E949E) & "; -fx-alignment: center; -fx-background-insets: 0; -fx-border-width: 0;")
	txtPlayerCode.PromptText = MessageValue("setup_placeholder").ToUpperCase

	confirmPane.Visible = False
	LayoutUi(Root.Width, Root.Height)
End Sub

Private Sub LayoutUi(Width As Int, Height As Int)
	Dim safeWidth As Int = Max(Width, 320dip)
	Dim safeHeight As Int = Max(Height, 420dip)
	Dim outerPad As Int = ScaleValue(safeWidth, 12dip, 20dip, 20dip)
	Dim horizontalPad As Int = ScaleValue(safeWidth, 12dip, 16dip, 24dip)
	Dim sectionGap As Int = ScaleValue(safeWidth, 24dip, 32dip, 48dip)
	Dim contentGap As Int = ScaleValue(safeWidth, 8dip, 12dip, 12dip)
	Dim headerHeight As Int = ScaleValue(safeWidth, 56dip, 64dip, 72dip)
	Dim footerHeight As Int = headerHeight
	Dim cardWidth As Int = Min(620dip, safeWidth - outerPad * 2)
	Dim preferredHeight As Int = Max(400dip, safeHeight - outerPad * 2)
	Dim cardHeight As Int = Min(preferredHeight, safeHeight - 8dip)
	Dim cardLeft As Int = (safeWidth - cardWidth) / 2
	Dim cardTop As Int = (safeHeight - cardHeight) / 2

	card.SetLayoutAnimated(0, cardLeft, cardTop, cardWidth, cardHeight)
	headerPane.SetLayoutAnimated(0, 0, 0, cardWidth, headerHeight)
	contentPane.SetLayoutAnimated(0, 0, headerHeight + sectionGap / 2, cardWidth, cardHeight - headerHeight - footerHeight - sectionGap)
	footerPane.SetLayoutAnimated(0, 0, cardHeight - footerHeight, cardWidth, footerHeight)

	headerActionPane.SetLayoutAnimated(0, cardWidth - horizontalPad - 32dip, (headerHeight - 32dip) / 2, 32dip, 32dip)
	lblHeaderAction.SetLayoutAnimated(0, 0, 0, headerActionPane.Width, headerActionPane.Height)
	lblHeader.SetLayoutAnimated(0, horizontalPad + 32dip + contentGap, 0, cardWidth - (horizontalPad + 32dip + contentGap) * 2, headerHeight)

	setupPane.SetLayoutAnimated(0, 0, 0, contentPane.Width, contentPane.Height)
	playerPane.SetLayoutAnimated(0, 0, 0, contentPane.Width, contentPane.Height)

	Dim contentHeight As Int = contentPane.Height
	Dim heroHeight As Int = Max(160dip, (contentHeight - sectionGap) / 2)
	Dim detailHeight As Int = Max(120dip, contentHeight - heroHeight - sectionGap)
	Dim contentWidth As Int = cardWidth - horizontalPad * 2

	setupHeroPane.SetLayoutAnimated(0, horizontalPad, 0, contentWidth, heroHeight)
	setupDetailPane.SetLayoutAnimated(0, horizontalPad, heroHeight + sectionGap, contentWidth, detailHeight)
	playerHeroPane.SetLayoutAnimated(0, horizontalPad, 0, contentWidth, heroHeight)
	playerDetailPane.SetLayoutAnimated(0, horizontalPad, heroHeight + sectionGap, contentWidth, detailHeight)

	Dim controlSize As Int = ScaleValue(safeWidth, 144dip, 160dip, 168dip)
	Dim inputLeft As Int = (setupHeroPane.Width - controlSize) / 2
	Dim inputTop As Int = Max(0, (setupHeroPane.Height - controlSize) / 2)
	accessCirclePane.SetLayoutAnimated(0, inputLeft, inputTop, controlSize, controlSize)
	txtPlayerCodeView.SetLayoutAnimated(0, 18dip, (controlSize - 32dip) / 2, controlSize - 36dip, 32dip)

	Dim orbitSize As Int = controlSize + 20dip
	Dim orbitLeft As Int = (playerHeroPane.Width - orbitSize) / 2
	Dim controlLeft As Int = (playerHeroPane.Width - controlSize) / 2
	Dim controlTop As Int = Max(0, (playerHeroPane.Height - controlSize) / 2)
	orbitPane.SetLayoutAnimated(0, orbitLeft, controlTop - 10dip, orbitSize, orbitSize)
	playButtonPane.SetLayoutAnimated(0, controlLeft, controlTop, controlSize, controlSize)
	lblPlayIcon.SetLayoutAnimated(0, 0, 0, controlSize, controlSize)

	setupPrimaryPane.SetLayoutAnimated(0, 0, 0, setupDetailPane.Width, Max(56dip, setupDetailPane.Height * 0.38))
	setupStatusPane.SetLayoutAnimated(0, 0, setupPrimaryPane.Height + contentGap, setupDetailPane.Width, setupDetailPane.Height - setupPrimaryPane.Height - contentGap)
	btnSetupSubmit.SetLayoutAnimated(0, Max(0, (setupPrimaryPane.Width - 132dip) / 2), Max(0, (setupPrimaryPane.Height - 44dip) / 2), 132dip, 44dip)
	lblSetupMessage.SetLayoutAnimated(0, 0, 0, setupStatusPane.Width, setupStatusPane.Height)

	playerPrimaryPane.SetLayoutAnimated(0, 0, 0, playerDetailPane.Width, Max(56dip, playerDetailPane.Height * 0.4))
	playerStatusPane.SetLayoutAnimated(0, 0, playerPrimaryPane.Height + contentGap, playerDetailPane.Width, playerDetailPane.Height - playerPrimaryPane.Height - contentGap)
	lblStream.SetLayoutAnimated(0, 0, 0, playerPrimaryPane.Width, playerPrimaryPane.Height)
	Dim infoHeight As Int = Max(54dip, playerStatusPane.Height - ConfirmReservedHeight)
	lblInfo.SetLayoutAnimated(0, 0, 0, playerStatusPane.Width, infoHeight)
	If confirmPane.Visible Then
		confirmPane.SetLayoutAnimated(0, 0, playerStatusPane.Height - 72dip, playerStatusPane.Width, 72dip)
	Else
		confirmPane.SetLayoutAnimated(0, 0, playerStatusPane.Height, playerStatusPane.Width, 0)
	End If
	btnConfirmYes.SetLayoutAnimated(0, Max(0, (confirmPane.Width - 236dip) / 2), 14dip, 112dip, 44dip)
	btnConfirmNo.SetLayoutAnimated(0, btnConfirmYes.Left + 124dip, 14dip, 112dip, 44dip)

	lblFooter.SetLayoutAnimated(0, horizontalPad, 0, cardWidth - horizontalPad * 2, footerHeight)
	UpdateResponsiveStyles(safeWidth)
	UpdateVisibleMode
End Sub

Private Sub ConfirmReservedHeight As Int
	If confirmPane.Visible Then Return 84dip
	Return 0
End Sub

Private Sub UpdateResponsiveStyles(AvailableWidth As Int)
	Dim small As Boolean = AvailableWidth <= 420dip
	Dim medium As Boolean = AvailableWidth <= 720dip
	Dim streamFontSize As Float
	Dim infoFontSize As Float
	Dim playFontSize As Float
	Dim cardRadius As Int

	If small Then
		streamFontSize = 28
		infoFontSize = 16
		playFontSize = 42
		cardRadius = 16dip
	Else If medium Then
		streamFontSize = 32
		infoFontSize = 17
		playFontSize = 48
		cardRadius = 20dip
	Else
		streamFontSize = 38
		infoFontSize = 17
		playFontSize = 48
		cardRadius = 24dip
	End If

	lblStream.Font = xui.CreateDefaultFont(streamFontSize)
	lblInfo.Font = xui.CreateDefaultFont(infoFontSize)
	lblHeader.Font = xui.CreateDefaultFont(12)
	lblFooter.Font = xui.CreateDefaultFont(12)
	lblHeaderAction.Font = xui.CreateDefaultFont(22)
	lblPlayIcon.Font = xui.CreateDefaultBoldFont(playFontSize)
	card.SetColorAndBorder(0xFF1A1B1E, 1dip, 0x14FFFFFF, cardRadius)
End Sub

Private Sub ShowInitialScreen
	If playerCode = "" Then
		ShowSetupScreen("")
	Else
		ShowPlayerScreen(True)
	End If
End Sub

Private Sub ShowSetupScreen(Text As String)
	appScreenMode = "setup"
	ClearPlaybackState
	HidePin
	isStarted = False
	isStoppedByUser = True
	SetPlayIcon
	SetStatusText("")
	lblHeader.Text = ""
	ConfigureSetupScreen("setup", Text)
	UpdateVisibleMode
	If txtPlayerCode.IsInitialized Then txtPlayerCode.RequestFocus
End Sub

Private Sub ShowSettingsScreen
	If playerCode = "" Then
		ShowSetupScreen("")
		Return
	End If
	appScreenMode = "settings"
	ConfigureSetupScreen("settings", "")
	UpdateVisibleMode
End Sub

Private Sub ShowPlayerScreen(RefreshInfo As Boolean)
	appScreenMode = "player"
	ConfigurePlayerHeader
	UpdateVisibleMode
	If isStarted = False Then ApplyStoppedState
	If RefreshInfo = False Then Return
	RenderPlayerHead(playerCode, "")
	Wait For (InitPlayerInfo) Complete (Unused As Boolean)
End Sub

Private Sub ConfigureSetupScreen(Mode As String, Text As String)
	Dim isSettingsMode As Boolean = Mode = "settings"
	headerActionPane.Visible = Mode <> "setup"
	If isSettingsMode Then
		lblHeaderAction.Text = "×"
	Else
		lblHeaderAction.Text = Chr(0x22EF)
	End If
	If isSettingsMode Then
		txtPlayerCode.Editable = False
	Else
		txtPlayerCode.Editable = True
	End If
	txtPlayerCode.Text = FormatPlayerCodeForDisplay(playerCode)
	If isSettingsMode Then
		btnSetupSubmit.Text = MessageValue("logout").ToUpperCase
	Else
		btnSetupSubmit.Text = MessageValue("setup_submit").ToUpperCase
	End If
	If Text <> "" Then
		lblSetupMessage.Text = Text
	Else If isSettingsMode Then
		lblSetupMessage.Text = MessageValue("settings_thanks")
	Else
		lblSetupMessage.Text = MessageValue("setup_title")
	End If
	If playerCode = "" Then lblHeader.Text = ""
End Sub

Private Sub ConfigurePlayerHeader
	headerActionPane.Visible = True
	lblHeaderAction.Text = Chr(0x22EF)
End Sub

Private Sub UpdateVisibleMode
	setupPane.Visible = appScreenMode <> "player"
	If appScreenMode = "player" Then
		playerPane.Visible = True
	Else
		playerPane.Visible = False
	End If
	If appScreenMode = "setup" Then headerActionPane.Visible = False
End Sub

Private Sub PlayButtonPane_Click
	If playerCode = "" Then
		ShowSetupScreen(MessageValue("player_required"))
		Return
	End If
	If isStarted = False Then
		If isStopping Then Return
		isStarted = True
		isStoppedByUser = False
		SetStopIcon
		HideContentBlocks
		Wait For (StartFirstTrack("manual")) Complete (Unused As Boolean)
		Return
	End If
	If isStopping Then Return
	Wait For (StopPlayer) Complete (Unused2 As Boolean)
End Sub

Private Sub HeaderActionPane_Click
	If appScreenMode = "player" Then
		ShowSettingsScreen
	Else If appScreenMode = "settings" Then
		ShowPlayerScreen(False)
	End If
End Sub

Private Sub BtnSetupSubmit_Click
	If appScreenMode = "settings" Then
		Wait For (LogoutPlayer) Complete (Unused As Boolean)
	Else
		Wait For (SubmitPlayerCode) Complete (Unused2 As Boolean)
	End If
End Sub

Private Sub BtnConfirmYes_Click
	Wait For (SubmitClaim) Complete (Unused As Boolean)
End Sub

Private Sub BtnConfirmNo_Click
	HidePin
	ApplyStoppedState
End Sub

Private Sub txtPlayerCode_TextChanged (Old As String, New As String)
	If appScreenMode = "settings" Then Return
	Dim filtered As String = FilterPlayerCode(New)
	If filtered <> New Then
		txtPlayerCode.Text = filtered
	End If
End Sub

Private Sub txtPlayerCode_Action
	If appScreenMode = "settings" Then Return
	BtnSetupSubmit_Click
End Sub

Private Sub SubmitPlayerCode As ResumableSub
	Dim nextPlayer As String = NormalizePlayerCode(txtPlayerCode.Text)
	If nextPlayer = "" Then
		ShowSetupScreen(MessageValue("setup_invalid"))
		txtPlayerCode.RequestFocus
		Return False
	End If
	playerCode = nextPlayer
	SaveValue("player_code", playerCode)
	txtPlayerCode.Text = FormatPlayerCodeForDisplay(playerCode)
	ShowPlayerScreen(True)
	Return True
End Sub

Private Sub LogoutPlayer As ResumableSub
	SaveValue("player_code", "")
	playerCode = ""
	Wait For (StopPlayer) Complete (Unused As Boolean)
	SetStatusText("")
	ShowSetupScreen("")
	Return True
End Sub

Private Sub InitPlayerInfo As ResumableSub
	If playerCode = "" Then Return False
	Wait For (FetchJsonWithTimeout(PLAYER_BASE_URL & "?" & BuildParams(CreateMetaParams), FETCH_TIMEOUT_MS)) Complete (result As FetchResult)
	If result.Success = False Then
		playerLevel = 1
		RenderPlayerHead(playerCode, "")
		Return False
	End If
	If result.Data Is Map Then
		Dim data As Map = result.Data
		If data.GetDefault("ok", False) <> True Then
			playerLevel = 1
			RenderPlayerHead(playerCode, "")
			Return False
		End If
		playerLevel = ResolvePlayerLevel(data.Get("level"))
		RenderPlayerHead(data.GetDefault("code", playerCode), data.GetDefault("title", ""))
		Return True
	End If
	playerLevel = 1
	RenderPlayerHead(playerCode, "")
	Return False
End Sub

Private Sub StartFirstTrack(Mode As String) As ResumableSub
	nextStartMode = Mode
	playQueue.Clear
	prefetchDone = False
	Wait For (LoadNextAndPlay) Complete (Unused As Boolean)
	Return True
End Sub

Private Sub LoadNextAndPlay As ResumableSub
	ClearRetryTimer
	Wait For (FetchNext) Complete (result As FetchResult)
	If result.Success = False Then
		Wait For (HandleFetchFailure(result)) Complete (Unused As Boolean)
		Return False
	End If
	If isStarted = False Or isStoppedByUser Then Return False
	ResetRetryDelay
	Dim queue As List = NormalizeQueueResponse(result.Data)
	If queue.IsInitialized = False Or queue.Size = 0 Then
		HandleTemporaryState("server", "")
		Return False
	End If
	playQueue = queue
	Dim retryAfter As Int = NormalizeRetryAfter(result.Data)
	Wait For (PlayQueueItem(ShiftQueueItem, retryAfter)) Complete (Unused2 As Boolean)
	Return True
End Sub

Private Sub PlayPreparedOrLoadNext As ResumableSub
	ClearRetryTimer
	If playQueue.Size > 0 Then
		Wait For (PlayQueueItem(ShiftQueueItem, 0)) Complete (Unused As Boolean)
		Return True
	End If
	Wait For (LoadNextAndPlay) Complete (Unused2 As Boolean)
	Return True
End Sub

Private Sub PrefetchNext As ResumableSub
	If playQueue.Size > 0 Then Return False
	If HasPendingExactBreak Then Return False
	Wait For (FetchNext) Complete (result As FetchResult)
	If result.Success = False Or isStarted = False Or isStoppedByUser Then Return False
	Dim queue As List = NormalizeQueueResponse(result.Data)
	If queue.IsInitialized = False Or queue.Size = 0 Then Return False
	playQueue = queue
	Return True
End Sub

Private Sub FetchNext As ResumableSub
	Wait For (FetchJsonWithTimeout(NEXT_BASE_URL & "?" & BuildParams(CreateNextParams), FETCH_TIMEOUT_MS)) Complete (result As FetchResult)
	nextStartMode = ""
	Return result
End Sub

Private Sub FetchJsonWithTimeout(Url As String, TimeoutMs As Int) As ResumableSub
	Dim result As FetchResult
	result.Initialize
	result.Success = False
	result.Kind = "server"
	Dim j As HttpJob
	j.Initialize("", Me)
	j.Download(Url)
	j.GetRequest.Timeout = TimeoutMs
	Wait For (j) JobDone(j As HttpJob)
	If j.Success Then
		Try
			Dim parser As JSONParser
			parser.Initialize(j.GetString)
			result.Data = parser.NextObject
			result.Success = True
			result.Kind = ""
		Catch
			result.Kind = "server"
			result.ErrorMessage = "bad_json"
		End Try
	Else
		result.ErrorMessage = j.ErrorMessage
		If result.ErrorMessage.ToLowerCase.Contains("timed out") Or result.ErrorMessage.ToLowerCase.Contains("unknownhost") Or result.ErrorMessage.ToLowerCase.Contains("refused") Then
			result.Kind = "offline"
		Else
			result.Kind = "server"
		End If
	End If
	j.Release
	Return result
End Sub

Private Sub SubmitClaim As ResumableSub
	btnConfirmYes.Enabled = False
	btnConfirmNo.Enabled = False
	Wait For (FetchJsonWithTimeout(CLAIM_BASE_URL & "?" & BuildParams(CreateClaimParams), FETCH_TIMEOUT_MS)) Complete (result As FetchResult)
	If result.Success Then
		If result.Data Is Map Then
		Dim data As Map = result.Data
		If data.GetDefault("ok", False) = True Then
			isStarted = True
			isStoppedByUser = False
			SetStopIcon
			HideContentBlocks
			Wait For (StartFirstTrack("manual")) Complete (Unused As Boolean)
			btnConfirmYes.Enabled = True
			btnConfirmNo.Enabled = True
			Return True
		End If
		End If
	End If
	ShowClaimPrompt(ResolveErrorMessage(result, MessageValue("device_busy")))
	btnConfirmYes.Enabled = True
	btnConfirmNo.Enabled = True
	Return False
End Sub

Private Sub PlayQueueItem(Current As Object, RetryAfter As Int) As ResumableSub
	ClearExactBreakState
	ClearHistoryLogTimer
	If Current Is Map Then
		Dim item As Map = Current
		Dim itemType As String = item.GetDefault("type", "")
		
		If itemType = "message" Then
			HandleMessageItem(item)
			Return False
		End If
		If itemType = "update" Then
			ClearPlaybackState
			isStarted = False
			isStoppedByUser = True
			SetPlayIcon
			ShowMessage(item.GetDefault("message", MessageValue("player_reloading")))
			Return False
		End If
		
		HidePin
		If itemType = "idle" Then
			ClearPlaybackState
			ShowMessage(item.GetDefault("message", MessageValue("idle")))
			If RetryAfter > 0 Then
				ScheduleRetry("server", RetryAfter * 1000)
			Else
				ScheduleRetry("server", PAUSE_RETRY_DELAY)
			End If
			Return False
		End If
		
		If itemType = "break" Then
			MergeBreakItems(item)
			Wait For (PlayPreparedOrLoadNext) Complete (Unused As Boolean)
			Return True
		End If
		
		If itemType <> "track" And itemType <> "ad" Then
			HandleTemporaryState("server", "")
			Return False
		End If
		
		Dim url As String = MediaUrl(item)
		If url = "" Then
			HandleTemporaryState("server", "")
			Return False
		End If
		
		If item.ContainsKey("playlist") Then playlistIndex = item.Get("playlist")
		prefetchDone = False
		If itemType = "ad" Then
			ShowAdMeta(item)
			ShowStream(MessageValue("ad_label"))
		Else
			ShowTrackMeta(item)
			ShowStream(item.GetDefault("stream", ""))
			SyncExactBreakState
		End If
		
		currentTrackUrl = url
		currentMediaType = itemType
		audio.LoadUrl(url, CurrentVolume(item))
		Wait For Audio_Ready
		If isStarted = False Or isStoppedByUser Then Return False
		audio.Play
		ScheduleHistoryLog(item)
		ResetRetryDelay
		Return True
	Else
		HandleTemporaryState("server", "")
		Return False
	End If
End Sub

Private Sub HandleMessageItem(Item As Map)
	Dim action As String = Item.GetDefault("action", "")
	If action = "claim" Then
		ClearPlaybackState
		isStarted = False
		isStoppedByUser = True
		SetPlayIcon
		ShowClaimPrompt(Item.GetDefault("message", MessageValue("device_busy")))
	Else If action = "blocked" Then
		HandleBlockedState
	Else If action = "not_found" Then
		StopForMissingData(Item.GetDefault("message", MessageValue("not_found")))
	Else
		HandleTemporaryState("server", Item.GetDefault("message", MessageValue("server_wait")))
	End If
End Sub

Private Sub MergeBreakItems(Item As Map)
	Dim items As List = Item.GetDefault("items", Null)
	If items.IsInitialized = False Or items.Size = 0 Then Return
	Dim merged As List
	merged.Initialize
	For Each breakItem As Object In items
		merged.Add(breakItem)
	Next
	For Each existing As Object In playQueue
		merged.Add(existing)
	Next
	playQueue = merged
End Sub

Private Sub HandleFetchFailure(Result As FetchResult) As ResumableSub
	If Result.Kind = "offline" Then
		HandleTemporaryState("offline", "")
		Return True
	End If
	Wait For (CheckExternalConnectivity) Complete (hasInternet As Boolean)
	If hasInternet Then
		HandleTemporaryState("server", "")
	Else
		HandleTemporaryState("offline", "")
	End If
	Return True
End Sub

Private Sub CheckExternalConnectivity As ResumableSub
	Dim j As HttpJob
	j.Initialize("", Me)
	j.Download(CONNECTIVITY_CHECK_URL & "?t=" & DateTime.Now)
	j.GetRequest.Timeout = CONNECTIVITY_CHECK_TIMEOUT_MS
	Wait For (j) JobDone(j As HttpJob)
	Dim ok As Boolean = j.Success
	j.Release
	Return ok
End Sub

Private Sub HandleTemporaryState(Mode As String, Text As String)
	ClearPlaybackState
	HidePin
	If Text <> "" Then
		ShowMessage(Text)
	Else If Mode = "offline" Then
		ShowMessage(MessageValue("offline"))
	Else
		ShowMessage(MessageValue("server_wait"))
	End If
	ScheduleRetry(Mode, 0)
End Sub

Private Sub HandleBlockedState
	ClearPlaybackState
	HidePin
	ShowMessage(MessageValue("blocked"))
	ScheduleRetry("blocked", 0)
End Sub

Private Sub StopForMissingData(Text As String)
	ClearPlaybackState
	HidePin
	isStarted = False
	isStoppedByUser = True
	SetPlayIcon
	ShowMessage(Text)
End Sub

Private Sub HandleMediaError As ResumableSub
	Wait For (CheckExternalConnectivity) Complete (hasInternet As Boolean)
	If hasInternet Then
		HandleTemporaryState("server", "")
	Else
		HandleTemporaryState("offline", "")
	End If
	Return True
End Sub

Private Sub ResolveRetryDelay(Mode As String, DelayMs As Int) As Int
	If DelayMs > 0 Then Return DelayMs
	If Mode = "offline" Then
		Dim delay As Int = offlineRetryDelay
		offlineRetryDelay = Min(offlineRetryDelay * 2, OFFLINE_RETRY_DELAY_MAX)
		Return delay
	End If
	If Mode = "blocked" Then Return BLOCKED_RETRY_DELAY
	Dim serverDelay As Int = serverRetryDelay
	serverRetryDelay = Min(serverRetryDelay * 2, SERVER_RETRY_DELAY_MAX)
	Return serverDelay
End Sub

Private Sub ScheduleRetry(Mode As String, DelayMs As Int)
	ClearRetryTimer
	retryTimer.Interval = ResolveRetryDelay(Mode, DelayMs)
	retryTimer.Enabled = True
End Sub

Private Sub RetryTimer_Tick
	retryTimer.Enabled = False
	If isStarted = False Or isStoppedByUser Then Return
	Wait For (LoadNextAndPlay) Complete (Unused As Boolean)
End Sub

Private Sub ResetRetryDelay
	offlineRetryDelay = OFFLINE_RETRY_DELAY_INITIAL
	serverRetryDelay = SERVER_RETRY_DELAY_INITIAL
End Sub

Private Sub ClearRetryTimer
	retryTimer.Enabled = False
End Sub

Private Sub ResolveScheduledBreakAt
	scheduledBreakAt = -1
	For Each itemObj As Object In playQueue
		If itemObj Is Map Then
			Dim item As Map = itemObj
			If item.GetDefault("type", "") = "break" And item.GetDefault("exactly", False) = True And item.ContainsKey("at") Then
				scheduledBreakAt = item.Get("at")
				Exit
			End If
		End If
	Next
End Sub

Private Sub SyncExactBreakState
	ResolveScheduledBreakAt
	ScheduleBreakWatch
End Sub

Private Sub ScheduleBreakWatch
	breakTimer.Enabled = False
	If HasPendingExactBreak = False Then Return
	Dim delay As Long = Max(1, ((scheduledBreakAt - LocalNowTimestamp) * 1000) - 250)
	breakTimer.Interval = delay
	breakTimer.Enabled = True
End Sub

Private Sub BreakTimer_Tick
	breakTimer.Enabled = False
	If isStarted = False Or isStoppedByUser Then Return
	If ShouldTriggerBreakNow = False Then Return
	Wait For (FadeOutAndContinue) Complete (Unused As Boolean)
End Sub

Private Sub ClearExactBreakState
	scheduledBreakAt = -1
	breakTimer.Enabled = False
End Sub

Private Sub HasPendingExactBreak As Boolean
	Return scheduledBreakAt > LocalNowTimestamp
End Sub

Private Sub ShouldTriggerBreakNow As Boolean
	If scheduledBreakAt <= 0 Then Return False
	Return LocalNowTimestamp >= scheduledBreakAt
End Sub

Private Sub EffectiveTrackRemainMs As Long
	Dim trackRemain As Long = 0
	If audio.Duration > 0 Then trackRemain = audio.Duration - audio.Position
	If scheduledBreakAt <= 0 Then Return trackRemain
	Dim breakRemain As Long = (scheduledBreakAt - LocalNowTimestamp) * 1000
	If trackRemain <= 0 Then Return breakRemain
	Return Min(trackRemain, breakRemain)
End Sub

Private Sub FadeOutAndContinue As ResumableSub
	If isQueueTransitioning Then Return False
	isQueueTransitioning = True
	ClearExactBreakState
	Dim fadeMs As Int
	If currentMediaType = "track" Then
		fadeMs = STOP_FADE_MS
	Else
		fadeMs = 0
	End If
	audio.Stop(fadeMs)
	Wait For (PlayPreparedOrLoadNext) Complete (Unused As Boolean)
	isQueueTransitioning = False
	Return True
End Sub

Private Sub ScheduleHistoryLog(Item As Map)
	If Item.IsInitialized = False Then Return
	Dim itemType As String = Item.GetDefault("type", "")
	If itemType <> "track" And itemType <> "ad" Then Return
	If Item.GetDefault("id", "") = "" Then Return
	ClearHistoryLogTimer
	historyItem = Item
	historyTimer.Interval = HISTORY_LOG_DELAY_MS
	historyTimer.Enabled = True
End Sub

Private Sub HistoryTimer_Tick
	historyTimer.Enabled = False
	If isStarted = False Or isStoppedByUser Then Return
	If historyItem.IsInitialized = False Then Return
	If currentMediaType <> historyItem.GetDefault("type", "") Then Return
	If currentTrackUrl = "" Then Return
	Wait For (SendHistory(historyItem)) Complete (Unused As Boolean)
End Sub

Private Sub SendHistory(Item As Map) As ResumableSub
	Dim params As Map
	params.Initialize
	params.Put("player", playerCode)
	params.Put("device", deviceId)
	params.Put("type", Item.GetDefault("type", ""))
	params.Put("id", Item.GetDefault("id", ""))
	params.Put("date", DateTime.Date(DateTime.Now))
	params.Put("time", DateTime.Time(DateTime.Now))
	Dim j As HttpJob
	j.Initialize("", Me)
	j.PostString(HISTORY_BASE_URL, BuildParams(params))
	j.GetRequest.Timeout = 5000
	j.GetRequest.SetContentType("application/x-www-form-urlencoded;charset=UTF-8")
	Wait For (j) JobDone(j As HttpJob)
	j.Release
	Return True
End Sub

Private Sub ClearHistoryLogTimer
	historyTimer.Enabled = False
	historyItem.Initialize
End Sub

Private Sub StopPlayer As ResumableSub
	If isStopping Then Return False
	isStopping = True
	isStarted = False
	isStoppedByUser = True
	ClearRetryTimer
	ClearExactBreakState
	ClearHistoryLogTimer
	ResetRetryDelay
	audio.Stop(STOP_FADE_MS)
	currentTrackUrl = ""
	currentMediaType = ""
	playlistIndex = -1
	playQueue.Clear
	prefetchDone = False
	SetStatusText("")
	HidePin
	SetPlayIcon
	ApplyStoppedState
	isStopping = False
	Return True
End Sub

Private Sub ClearPlaybackState
	audio.Reset
	currentTrackUrl = ""
	currentMediaType = ""
	playQueue.Clear
	prefetchDone = False
	ClearRetryTimer
	ClearExactBreakState
	ClearHistoryLogTimer
	SetStatusText("")
End Sub

Private Sub Audio_Ready
End Sub

Private Sub Audio_Error(Message As String)
	If isStoppedByUser Or isStopping Then Return
	Wait For (HandleMediaError) Complete (Unused As Boolean)
End Sub

Private Sub Audio_Complete
	If isStoppedByUser Then Return
	Wait For (PlayPreparedOrLoadNext) Complete (Unused As Boolean)
End Sub

Private Sub Audio_Timeupdate
	If isStarted = False Or isStoppedByUser Then Return
	If ShouldTriggerBreakNow Then
		Wait For (FadeOutAndContinue) Complete (Unused As Boolean)
		Return
	End If
	If prefetchDone Then Return
	Dim remain As Long = EffectiveTrackRemainMs
	If remain <= 0 Then Return
	If remain <= PREFETCH_SECONDS * 1000 Then
		prefetchDone = True
		Wait For (PrefetchNext) Complete (Unused2 As Boolean)
	End If
End Sub

Private Sub SetPlayIcon
	SetLabelStyle(lblPlayIcon, "-fx-alignment: center; -fx-text-fill: " & ColorToCss(0xFFD0FF71) & ";")
	lblPlayIcon.Text = "▶"
	orbitPane.SetColorAndBorder(xui.Color_Transparent, 2dip, 0x00D0FF71, 999dip)
	playButtonPane.SetColorAndBorder(xui.Color_Transparent, 4dip, 0x33FFFFFF, 999dip)
End Sub

Private Sub SetStopIcon
	SetLabelStyle(lblPlayIcon, "-fx-alignment: center; -fx-text-fill: " & ColorToCss(0xFFD0FF71) & ";")
	lblPlayIcon.Text = "■"
	orbitPane.SetColorAndBorder(xui.Color_Transparent, 2dip, 0x66D0FF71, 999dip)
	playButtonPane.SetColorAndBorder(0x08FFFFFF, 4dip, 0x55FFFFFF, 999dip)
End Sub

Private Sub ApplyStoppedState
	ShowStream(MessageValue("idle_stream"))
	SetStatusText("")
End Sub

Private Sub HideContentBlocks
	HidePin
	SetStreamText("")
	SetStatusText("")
	btnConfirmYes.Enabled = True
	btnConfirmNo.Enabled = True
End Sub

Private Sub ShowStream(Text As String)
	SetStreamText(Text)
End Sub

Private Sub ShowMessage(Text As String)
	HideContentBlocks
	SetStatusText(Text)
End Sub

Private Sub ShowClaimPrompt(Text As String)
	HideContentBlocks
	isStarted = False
	isStoppedByUser = True
	SetPlayIcon
	SetStatusText(Text)
	confirmPane.Visible = True
	LayoutUi(Root.Width, Root.Height)
End Sub

Private Sub HidePin
	confirmPane.Visible = False
	btnConfirmYes.Enabled = True
	btnConfirmNo.Enabled = True
End Sub

Private Sub ShowTrackMeta(Item As Map)
	Dim parts As List
	parts.Initialize
	If Item.GetDefault("set", "") <> "" Then parts.Add(Item.Get("set"))
	If Item.GetDefault("code", "") <> "" Then parts.Add(Item.Get("code"))
	SetStatusText(JoinList(parts, " • "))
End Sub

Private Sub ShowAdMeta(Item As Map)
	SetStatusText(Item.GetDefault("title", ""))
End Sub

Private Sub SetStreamText(Text As String)
	lblStream.Text = Text
End Sub

Private Sub SetStatusText(Text As String)
	lblInfo.Text = Text
End Sub

Private Sub RenderPlayerHead(Code As String, Title As String)
	Dim safeCode As String = FormatPlayerCodeForDisplay(Code)
	If Title <> "" Then
		lblHeader.Text = safeCode & " • " & Title.ToUpperCase
	Else
		lblHeader.Text = safeCode
	End If
End Sub

Private Sub MediaUrl(Item As Map) As String
	Dim id As String = Item.GetDefault("id", "")
	If id = "" Then Return ""
	Dim first As String = id.SubString2(0, 1)
	Dim folder As String
	If Item.GetDefault("type", "") = "ad" Then
		folder = "ads"
	Else
		folder = "tracks"
	End If
	Return "https://cdn.fon.fm/media/" & folder & "/" & first & "/" & id & ".mp3"
End Sub

Private Sub CurrentVolume(Item As Map) As Int
	Dim volume As Double = 0.7
	If Item.ContainsKey("volume") Then volume = Item.Get("volume")
	If volume < 0 Then volume = 0
	If volume > 1 Then volume = 1
	Return Round(volume * 100)
End Sub

Private Sub NormalizeQueueResponse(Data As Object) As List
	If Data Is Map Then
		Dim m As Map = Data
		Dim items As List = m.GetDefault("queue", Null)
		If items.IsInitialized = False Then Return Null
		Dim normalized As List
		normalized.Initialize
		For Each item As Object In items
			If item Is Map Then normalized.Add(item)
		Next
		Return normalized
	End If
	Return Null
End Sub

Private Sub NormalizeRetryAfter(Data As Object) As Int
	If Data Is Map Then
		Dim m As Map = Data
		If m.ContainsKey("retry_after") = False Then Return 0
		Dim value As Int = m.Get("retry_after")
		If value <= 0 Then Return 0
		Return value
	End If
	Return 0
End Sub

Private Sub ShiftQueueItem As Object
	If playQueue.Size = 0 Then Return Null
	Dim item As Object = playQueue.Get(0)
	playQueue.RemoveAt(0)
	Return item
End Sub

Private Sub ResolveErrorMessage(Result As FetchResult, Fallback As String) As String
	If Result.Success Then
		If Result.Data Is Map Then
			Dim m As Map = Result.Data
			If m.GetDefault("message", "") <> "" Then Return m.Get("message")
		End If
	End If
	If Result.ErrorMessage <> "" Then Return Result.ErrorMessage
	Return Fallback
End Sub

Private Sub CreateMetaParams As Map
	Dim params As Map
	params.Initialize
	params.Put("player", playerCode)
	params.Put("tz", TimezoneOffsetMinutes)
	Return params
End Sub

Private Sub CreateNextParams As Map
	Dim params As Map
	params.Initialize
	params.Put("player", playerCode)
	params.Put("device", deviceId)
	params.Put("tz", TimezoneOffsetMinutes)
	params.Put("version", APP_VERSION)
	If nextStartMode = "manual" Or nextStartMode = "auto" Then params.Put("start", nextStartMode)
	If playlistIndex >= 0 Then params.Put("playlist", playlistIndex)
	Return params
End Sub

Private Sub CreateClaimParams As Map
	Dim params As Map
	params.Initialize
	params.Put("player", playerCode)
	params.Put("device", deviceId)
	params.Put("tz", TimezoneOffsetMinutes)
	Return params
End Sub

Private Sub BuildParams(Params As Map) As String
	Dim sb As StringBuilder
	sb.Initialize
	For Each key As String In Params.Keys
		If sb.Length > 0 Then sb.Append("&")
		sb.Append(UrlEncode(key)).Append("=").Append(UrlEncode(Params.Get(key)))
	Next
	Return sb.ToString
End Sub

Private Sub UrlEncode(Value As Object) As String
	Dim jo As JavaObject
	jo.InitializeStatic("java.net.URLEncoder")
	Return jo.RunMethod("encode", Array(Value, "UTF-8"))
End Sub

Private Sub NormalizePlayerCode(Value As String) As String
	Dim code As String = Value.Trim.ToLowerCase
	If Regex.IsMatch("^[a-z0-9]{5}$", code) Then Return code
	Return ""
End Sub

Private Sub FilterPlayerCode(Value As String) As String
	Dim filtered As String = Regex.Replace("[^A-Za-z0-9]", Value, "")
	If filtered.Length > 5 Then filtered = filtered.SubString2(0, 5)
	Return filtered.ToUpperCase
End Sub

Private Sub FormatPlayerCodeForDisplay(Value As String) As String
	Return Value.Trim.ToUpperCase
End Sub

Private Sub GetOrCreateDeviceId As String
	Dim id As String = storage.GetDefault("device_id", "")
	If id <> "" Then Return id
	Dim jo As JavaObject
	jo.InitializeStatic("java.util.UUID")
	Dim uuid As JavaObject = jo.RunMethod("randomUUID", Null)
	id = uuid.RunMethod("toString", Null)
	SaveValue("device_id", id)
	Return id
End Sub

Private Sub LoadStorage As Map
	Dim m As Map
	m.Initialize
	If File.Exists(storageDir, storageFile) = False Then Return m
	Try
		Dim parser As JSONParser
		parser.Initialize(File.ReadString(storageDir, storageFile))
		m = parser.NextObject
	Catch
		m.Initialize
	End Try
	Return m
End Sub

Private Sub SaveValue(Key As String, Value As Object)
	storage.Put(Key, Value)
	Dim gen As JSONGenerator
	gen.Initialize(storage)
	File.WriteString(storageDir, storageFile, gen.ToString)
End Sub

Private Sub ResolvePlayerLevel(Value As Object) As Double
	If Value = Null Then Return 1
	Dim level As Double = Value
	If level < 0 Then level = 0
	If level > 100 Then level = 100
	Return level / 100
End Sub

Private Sub TimezoneOffsetMinutes As Int
	Dim jo As JavaObject
	jo.InitializeStatic("java.util.TimeZone")
	Dim tz As JavaObject = jo.RunMethod("getDefault", Null)
	Dim offsetMs As Long = tz.RunMethod("getOffset", Array(DateTime.Now))
	Return -Round(offsetMs / (1000 * 60))
End Sub

Private Sub LocalNowTimestamp As Long
	Return Floor(DateTime.Now / 1000) - (TimezoneOffsetMinutes * 60)
End Sub

Private Sub JoinList(Items As List, Separator As String) As String
	Dim sb As StringBuilder
	sb.Initialize
	For i = 0 To Items.Size - 1
		If i > 0 Then sb.Append(Separator)
		sb.Append(Items.Get(i))
	Next
	Return sb.ToString
End Sub

Private Sub MessageValue(Key As String) As String
	Return messages.GetDefault(Key, "")
End Sub

Private Sub CreateLabel(Text As String, FontSize As Float, TextColor As Int, Bold As Boolean, WrapText As Boolean) As B4XView
	Dim lbl As Label
	lbl.Initialize("")
	lbl.Text = Text
	lbl.WrapText = WrapText
	Dim xlbl As B4XView = lbl
	If Bold Then
		xlbl.Font = xui.CreateDefaultBoldFont(FontSize)
	Else
		xlbl.Font = xui.CreateDefaultFont(FontSize)
	End If
	xlbl.SetTextAlignment("CENTER", "CENTER")
	SetLabelStyle(xlbl, "-fx-alignment: center; -fx-text-fill: " & ColorToCss(TextColor) & ";")
	Return xlbl
End Sub

Private Sub CreateTextButton(Text As String, EventName As String) As B4XView
	Dim btn As Button
	btn.Initialize(EventName)
	Dim xbtn As B4XView = btn
	xbtn.Text = Text
	xbtn.Font = xui.CreateDefaultFont(12)
	SetPaneStyle(xbtn, "-fx-background-color: transparent; -fx-border-color: rgba(255,255,255,0.12); -fx-border-radius: 12; -fx-background-radius: 12; -fx-text-fill: " & ColorToCss(0xFFE0E4EA) & ";")
	Return xbtn
End Sub

Private Sub SetPaneStyle(View As B4XView, Style As String)
	Dim jo As JavaObject = View
	jo.RunMethod("setStyle", Array(Style))
End Sub

Private Sub SetLabelStyle(View As B4XView, Style As String)
	Dim jo As JavaObject = View
	jo.RunMethod("setStyle", Array(Style))
End Sub

Private Sub ScaleValue(AvailableWidth As Int, SmallValue As Int, MediumValue As Int, LargeValue As Int) As Int
	If AvailableWidth <= 420dip Then Return SmallValue
	If AvailableWidth <= 720dip Then Return MediumValue
	Return LargeValue
End Sub

Private Sub ColorToCss(Color As Int) As String
	Dim unsignedColor As Long = Bit.And(0xFFFFFFFF, Color)
	Dim rgb As Int = Bit.And(unsignedColor, 0xFFFFFF)
	Return "#" & Bit.ToHexString(rgb)
End Sub
